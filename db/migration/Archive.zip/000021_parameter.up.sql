---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Account_Param (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Param_Item_ID bigint NOT NULL,
  Type_ID bigint NOT NULL,
  Date_Implemented Date NOT NULL,
  Value_Int int8 NULL,
  Value_Decimal numeric(20,8) NULL,
  Value_Date Date NULL,
  Value_String varchar(1000) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Account_Param_pkey PRIMARY KEY (UUID),
  CONSTRAINT idxAccount_ParamID UNIQUE (Type_ID, Param_Item_ID, Date_Implemented),
  CONSTRAINT fk_Account_Param_Reference FOREIGN KEY (Param_Item_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Account_Param_Account_Type FOREIGN KEY (Type_ID) REFERENCES Account_Type(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccount_Param_UUID ON public.Account_Param(UUID);

DROP TRIGGER IF EXISTS trgAccount_Param_Ins on Account_Param;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Param_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Account_Param
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccount_Param_upd on Account_Param;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Param_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Account_Param
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

--------------------------------------------
-- CREATE Account_Param View
--------------------------------------------
CREATE OR REPLACE VIEW public.vwAccount_Param
AS SELECT 
    mr.UUID,
        
    Date_Implemented,
    rf.Value_Int, rf.Value_Decimal, rf.Value_Date, rf.Value_String,
    
    
    par.ID Param_Item_ID, par.UUID Param_ItemUUID, par.Title param_Item,
    y.ID Type_ID, y.UUID Account_Type_UUID, y.Account_Type,
    
    mr.Mod_Ctr,
    rf.Other_Info,
    mr.Created,
    mr.Updated 
   FROM Account_Param rf
     INNER JOIN Main_Record mr on mr.UUID = rf.UUID
     LEFT JOIN Reference par ON rf.Param_Item_ID = par.ID
     LEFT JOIN Account_Type y ON y.ID = rf.Type_ID;

--------------------------------------------
    INSERT into Account_Param(
      Type_ID, Param_Item_ID, Date_Implemented, 
      Value_Int, Value_Decimal, Value_Date, Value_String)     
    SELECT y.ID Type_ID, par.ID Param_Item_ID, cast(a.Date_Implemented as Date), 
      a.Value_Int, cast(a.Value_Decimal as decimal), cast(a.Value_Date as Date), a.Value_String
    FROM (Values
        ('Sikap 1', 'Interest', '2010-10-01',
         30, null, null, null))
        a(Account_Type, param_Item, Date_Implemented, 
          Value_Int, Value_Decimal, Value_Date, Value_String)
    LEFT JOIN vwReference par on par.Ref_Type = 'Parameter' and par.Title = a.param_Item
    INNER JOIN Account_Type y on y.Account_Type = a.Account_Type
    LEFT JOIN Account_Param p on par.ID = p.Param_Item_ID and y.ID = p.Type_ID 
    
    ON CONFLICT(Type_ID, Param_Item_ID, Date_Implemented) DO UPDATE SET
      Date_Implemented  = EXCLUDED.Date_Implemented, 
      Value_Int = EXCLUDED.Value_Int, 
      Value_Decimal = EXCLUDED.Value_Decimal, 
      Value_Date = EXCLUDED.Value_Date, 
      Value_String = EXCLUDED.Value_String 
    ;
