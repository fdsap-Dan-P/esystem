---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.reference_group (
---------------------------------------------------------------------------
  Group_Id bigint NOT NULL,
  Ref_Id bigint NOT NULL,
  Active Boolean NOT NULL,
  CONSTRAINT referencegroup_pkey PRIMARY KEY (Group_Id, Ref_Id)
);
