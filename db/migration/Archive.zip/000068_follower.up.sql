---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Follower (
---------------------------------------------------------------------------
  User_ID bigint NOT NULL,
  Follower_ID bigint NOT NULL,
  Date_Followed timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  is_Follower Boolean NOT NULL,
  CONSTRAINT Follower_pkey PRIMARY KEY (Follower_ID, User_ID),
  CONSTRAINT fkFollower_User FOREIGN KEY (User_ID) REFERENCES Users(ID),
  CONSTRAINT fkFollower_Follower FOREIGN KEY (Follower_ID) REFERENCES Users(ID)
);

CREATE INDEX IF NOT EXISTS idxFollower_user ON public.Follower(User_ID);
