CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
---------------------------------------------------------------------------
CREATE Sequence IF NOT EXISTS public.Mod_Ctr_seq
---------------------------------------------------------------------------
  INCREMENT BY 1
  MINValue 1
  MAXValue 9223372036854775807
  START 1
  CACHE 1
  NO CYCLE;

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Main_Record (
----------------------------------------------------------------------------------------
  UUID     uuid NOT NULL,
  Mod_Ctr   int8 NOT NULL,
  Created  timestamptz NULL,
  Updated  timestamptz NULL,
  CONSTRAINT Main_Record_pkey PRIMARY KEY (UUID)
);

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Modified (
----------------------------------------------------------------------------------------
  Mod_Ctr int8 NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  
  Updated timestamptz NULL,
  CONSTRAINT Modified_pkey PRIMARY KEY (Mod_Ctr),
  CONSTRAINT fkModifiedID FOREIGN KEY (UUID) REFERENCES Main_Record(UUID)
);

CREATE INDEX IF NOT EXISTS idxModified_UUID ON public.Modified(UUID);

-- INSERT Trigger
---------------------------------------------------------------------------
CREATE or REPLACE FUNCTION trgGenericInsert() returns trigger AS 
---------------------------------------------------------------------------
$$ 
DECLARE 
   ctr int8 := Nextval('Mod_Ctr_seq');
   upd timestamptz := CURRENT_TIMESTAMP;
BEGIN
   INSERT INTO Main_Record(UUID, Mod_Ctr, Created)
   SELECT NEW.UUID, ctr, upd
   ON CONFLICT DO NOTHING;
 
   INSERT INTO Modified(Mod_Ctr, UUID, Updated)
   SELECT ctr, NEW.UUID, upd;
 
   RETURN NEW;
   
END $$ Language plpgsql;

-- UPDATE Trigger
---------------------------------------------------------------------------
CREATE or REPLACE FUNCTION trgGenericUpdate() returns trigger AS 
---------------------------------------------------------------------------
$$ 

DECLARE 
   ctr int8 := Nextval('Mod_Ctr_seq');
   Upd timestamptz := CURRENT_TIMESTAMP;
BEGIN
     INSERT INTO Modified(Mod_Ctr, UUID, Updated)
     ValueS(ctr, NEW.UUID, upd);
   
     UPDATE Main_Record 
     SET Updated = Upd
     WHERE UUID = NEW.UUID;
   
     RETURN NEW;
END $$ Language plpgsql;

