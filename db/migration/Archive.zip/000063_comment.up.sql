---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Comment (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Record_UUID uuid NOT NULL,
  User_ID bigint NOT NULL, 
  Comment Text NOT NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Comment_pkey PRIMARY KEY (UUID),
  CONSTRAINT fkComment_Rec FOREIGN KEY (Record_UUID) REFERENCES Main_Record(UUID)
);

DROP TRIGGER IF EXISTS trgCommentIns on Comment;
---------------------------------------------------------------------------
CREATE TRIGGER trgCommentIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Comment
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgCommentupd on Comment;
---------------------------------------------------------------------------
CREATE TRIGGER trgCommentupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Comment
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

---------------------------------------------------------------------------
