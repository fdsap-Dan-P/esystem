----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.User_Config (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  User_ID bigint NOT NULL,
  Access_Config_ID bigint NOT NULL,
  Value_Int int8 NULL,
  Value_Decimal float8 NULL,
  Value_Date Date NULL,
  Value_String varchar(1000) NULL,
  Other_Info jsonb NULL,

  CONSTRAINT User_Config_pkey PRIMARY KEY (User_ID, Access_Config_ID),
  CONSTRAINT fkUser_ConfigUser   FOREIGN KEY (User_ID)   REFERENCES Users(ID),
  CONSTRAINT fkUser_ConfigConfig FOREIGN KEY (Access_Config_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxUser_Config_UUID ON public.User_Config(UUID);

DROP TRIGGER IF EXISTS trgUser_ConfigIns on User_Config;
---------------------------------------------------------------------------
CREATE TRIGGER trgUser_ConfigIns
---------------------------------------------------------------------------
    BEFORE INSERT ON User_Config
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
  
DROP TRIGGER IF EXISTS trgUser_Configupd on User_Config;
---------------------------------------------------------------------------
CREATE TRIGGER trgUser_Configupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON User_Config
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.vwUser_Config
----------------------------------------------------------------------------------------
  AS SELECT 
    mr.UUID,
    u.ID User_ID, u.Login_Name,
 
    y.ID Access_Config_ID, y.UUID Access_ConfigUUID, y.Title Account_Type,
  
    Value_Int,
    Value_Decimal,
    Value_Date,
    Value_String,
   
    mr.Mod_Ctr,
    uat.Other_Info,
    mr.Created,
    mr.Updated 
   FROM User_Config uat
   INNER JOIN Main_Record mr on mr.UUID = uat.UUID
   LEFT JOIN Reference y ON y.ID = uat.Access_Config_ID
   LEFT JOIN Users u ON u.ID = uat.User_ID
    ;

  INSERT INTO User_Config
   (User_ID, Access_Config_ID, Value_Int, Value_Decimal, Value_Date, Value_String)
  SELECT 
    u.ID User_ID, y.ID Access_Config_ID,
    a.Value_Int, cast(a.Value_Decimal as decimal), cast(a.Value_Date as Date), a.Value_String
  FROM
   (Values
    ('erick1421@gmail.com', 'PasswordComplexity', 0, null, null, null))
     a(Login_Name, Access_Config, Value_Int, Value_Decimal, Value_Date, Value_String)  
  INNER JOIN vwReference y on y.Title = a.Access_Config and y.Ref_Type = 'Access_Config'
  INNER JOIN Users   u on u.Login_Name = a.Login_Name
  
  ON CONFLICT(User_ID, Access_Config_ID) DO UPDATE SET
    Value_Int = EXCLUDED.Value_Int, 
    Value_Decimal = EXCLUDED.Value_Decimal, 
    Value_Date = EXCLUDED.Value_Date, 
    Value_String = EXCLUDED.Value_String
  ;
