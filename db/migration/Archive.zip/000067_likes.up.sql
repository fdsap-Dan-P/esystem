---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Likes (
---------------------------------------------------------------------------
  UUID uuid NOT NULL,
  User_ID bigint NOT NULL,
  Mood integer NOT NULL,  
  Date_Liked timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT Likes_pkey PRIMARY KEY (UUID, User_ID),
  CONSTRAINT fkLikes_User FOREIGN KEY (User_ID) REFERENCES Users(ID),
  CONSTRAINT fkLikes_UUID FOREIGN KEY (UUID) REFERENCES Main_Record(UUID)
);

CREATE INDEX IF NOT EXISTS idxLikes_UUID ON public.Likes(UUID);
