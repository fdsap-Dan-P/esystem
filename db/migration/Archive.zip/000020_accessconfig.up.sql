---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Access_Config (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Access_Role_ID bigint NOT NULL,
  Access_Config_ID bigint NOT NULL,
  Value_Int int8 NULL,
  Value_Decimal Numeric(20,8) NULL,
  Value_Date Date NULL,
  Value_String varchar(1000) NULL,
  Other_Info jsonb NULL,

  CONSTRAINT Access_Config_pkey PRIMARY KEY (Access_Role_ID, Access_Config_ID),
  CONSTRAINT fk_Access_Config_role   FOREIGN KEY (Access_Role_ID)   REFERENCES Access_Role(ID),
  CONSTRAINT fk_Access_Config_Config FOREIGN KEY (Access_Config_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccess_Config_UUID ON public.Access_Config(UUID);

--------------------------------------------
-- CREATE Reference View
--------------------------------------------
CREATE OR REPLACE VIEW public.vwAccess_Config
AS SELECT 
    mr.UUID,
    r.ID as Access_Role_ID,
    r.Access_Name,

    c.ID as Access_Config_ID, c.UUID as Access_ConfigUUID,
    c.Title as Access_Config,
        
    rf.Value_Int, rf.Value_Decimal, rf.Value_Date, rf.Value_String,

    mr.Mod_Ctr,
    rf.Other_Info,
    mr.Created,
    mr.Updated 
   FROM Access_Config rf
     INNER JOIN Main_Record mr on mr.UUID = rf.UUID
     LEFT JOIN Reference c ON rf.Access_Config_ID = c.ID
     LEFT JOIN Access_Role r ON r.ID = rf.Access_Role_ID;

DROP TRIGGER IF EXISTS trgAccess_Config_Ins on Access_Config;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccess_Config_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Access_Config
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccess_Config_upd on Access_Config;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccess_Config_upd
---------------------------------------------------------------------------
  BEFORE UPDATE ON Access_Config
  FOR EACH ROW
  WHEN (OLD.* IS DISTINCT FROM NEW.*)
  EXECUTE PROCEDURE trgGenericUpdate();

  INSERT INTO Access_Config(Access_Role_ID, Access_Config_ID, Value_Int, Value_Decimal, Value_Date, Value_String)
  SELECT 
    r.ID Access_Role_ID, c.ID Access_Config_ID, 
    a.Value Value_Int, null Value_Decimal, null Value_Date, null Value_String
  FROM (Values
      ('Admin', 'PasswordComplexity', 4),
      ('Bookkeeper', 'PasswordComplexity', 4),
      ('Cashier', 'PasswordComplexity', 4),
      ('Pastor', 'PasswordComplexity', 4),
      ('Member', 'PasswordComplexity', 4)
      )   
    a(Access_Name, Access_Config, Value), vwReference c, Access_Role r
   WHERE c.Ref_Type = 'Access_Config' and c.Title = a.Access_Config
     and r.Access_Name = a.Access_Name
   ORDER BY 1
  ON CONFLICT(Access_Role_ID, Access_Config_ID)
  DO UPDATE SET 
    Value_Int = EXCLUDED.Value_Int, 
    Value_Decimal = EXCLUDED.Value_Decimal, 
    Value_Date = EXCLUDED.Value_Date, 
    Value_String = EXCLUDED.Value_String;
