----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Inventory_Item (
----------------------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  BarCode varchar(48) NULL,
  Item_Name varchar(100) NOT NULL,
  Parent_ID bigint NULL,
  Generic_Name_ID bigint NULL,
  Brand_Name_ID bigint NULL,
  Measure_ID bigint NOT NULL,
  Remarks varchar(1000) NOT NULL,
  Other_Info jsonb NULL,  
  
  CONSTRAINT Inventory_Item_pkey PRIMARY KEY (ID),
  CONSTRAINT Inventory_Item_pkg FOREIGN KEY (Parent_ID) REFERENCES Inventory_Item(ID),
  CONSTRAINT fk_Inventory_Item_gen FOREIGN KEY (Generic_Name_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Inventory_Item_bn FOREIGN KEY (Brand_Name_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Inventory_Item_Unitmeasure FOREIGN KEY (Measure_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxInventory_Item_UUID ON public.Inventory_Item(UUID);

DROP TRIGGER IF EXISTS trgInventory_Item_Ins on Inventory_Item;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Item_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Inventory_Item
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgInventory_Item_upd on Inventory_Item;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Item_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Inventory_Item
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Account_Inventory (
----------------------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Account_ID bigint NOT NULL,
  BarCode varchar(48) NULL,
  Code varchar(50) NOT NULL,
  Inventory numeric(16,6) NOT NULL,
  Unit_Price numeric(16,6) NOT NULL, 
  Book_Value numeric(16,6) NOT NULL,
  Discount numeric(10,6) NOT NULL, 
  Tax_Rate numeric(10,6) NOT NULL,
  Remarks varchar(1000) NOT NULL,
  Other_Info jsonb NULL,  
  
  CONSTRAINT Account_Inventory_pkey PRIMARY KEY (ID),
  CONSTRAINT Account_Inventory_ID FOREIGN KEY (Account_ID) REFERENCES Account(ID),
  CONSTRAINT Account_Inventory_pkg FOREIGN KEY (Package_ID) REFERENCES Account_Inventory(ID),
  CONSTRAINT fk_Account_Inventory_Unitmeasure FOREIGN KEY (Measure_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccount_Inventory_UUID ON public.Account_Inventory(UUID);

DROP TRIGGER IF EXISTS trgAccount_Inventory_Ins on Account_Inventory;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Inventory_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Account_Inventory
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccount_Inventory_upd on Account_Inventory;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Inventory_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Account_Inventory
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Inventory_Detail (
----------------------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Account_Inventory_Id numeric(16,6) NOT NULL,
  Inventory_Item_Id numeric(16,6) NOT NULL,
  Unit_Price numeric(16,6) NOT NULL,
  Book_Value numeric(16,6) NOT NULL,
  Unit numeric(16,6) NOT NULL,
  Measure_ID bigint NOT NULL,
  Batch_Number varchar(30) NULL,
  Date_Manufactured  Date NULL,
  Date_Expired Date NULL,
  Remarks varchar(1000) NOT NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Inventory_Detail_pkey PRIMARY KEY (ID),
  CONSTRAINT Inventory_Detail_AccInv FOREIGN KEY (Account_Inventory_Id) REFERENCES Account_Inventory(ID),
  CONSTRAINT fk_Inventory_Detail_Unitmeasure FOREIGN KEY (Measure_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxInventory_Detail_UUID ON public.Inventory_Detail(UUID);
CREATE INDEX IF NOT EXISTS idxInventory_Detail_InvID ON public.Inventory_Detail(Account_Inventory_Id, Inventory_Item_Id);

DROP TRIGGER IF EXISTS trgInventory_Detail_Ins on Inventory_Detail;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Detail_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Inventory_Detail
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgInventory_Detail_upd on Inventory_Detail;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Detail_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Inventory_Detail
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Inventory_Specs_String (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Inventory_Item_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Value text NOT NULL,
  
  CONSTRAINT Inventory_Specs_String_pkey PRIMARY KEY (UUID),
  CONSTRAINT Inventory_Specs_String_ID FOREIGN KEY (Inventory_Item_ID) REFERENCES Inventory_Item(ID),
  CONSTRAINT Inventory_Specs_String_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxInventory_Specs_String_Unique ON public.Inventory_Specs_String(Inventory_Item_ID, Item_ID);

DROP TRIGGER IF EXISTS trgInventory_Specs_String_Ins on Inventory_Specs_String;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_String_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Inventory_Specs_String
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgInventory_Specs_String_upd on Inventory_Specs_String;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_String_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Inventory_Specs_String
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Inventory_Specs_Number (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Inventory_Item_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Value numeric(16,6) NOT NULL,
  Value2 numeric(16,6) NOT NULL,
  Measure_ID bigint NULL,

  CONSTRAINT Inventory_Specs_Number_pkey PRIMARY KEY (UUID),
  CONSTRAINT Inventory_Specs_Number_ID FOREIGN KEY (Inventory_Item_ID) REFERENCES Inventory_Item(ID),
  CONSTRAINT fk_Inventory_Specs_Unitmeasure FOREIGN KEY (Measure_ID) REFERENCES Reference(ID),
  CONSTRAINT Inventory_Specs_Number_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxInventory_Specs_Number_Unique ON public.Inventory_Specs_Number(Inventory_Item_ID, Item_ID);

DROP TRIGGER IF EXISTS trgInventory_Specs_Number_Ins on Inventory_Specs_Number;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_Number_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Inventory_Specs_Number
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgInventory_Specs_Number_upd on Inventory_Specs_Number;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_Number_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Inventory_Specs_Number
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Inventory_Specs_Date (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Inventory_Item_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Value Date NOT NULL,
  Value2 Date NOT NULL,
  
  CONSTRAINT Inventory_Specs_Date_pkey PRIMARY KEY (UUID),
  CONSTRAINT Inventory_Specs_Date_ID FOREIGN KEY (Inventory_Item_ID) REFERENCES Inventory_Item(ID),
  CONSTRAINT Inventory_Specs_Date_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxInventory_Specs_Date_Unique ON public.Inventory_Specs_Date(Account_Inventory_ID, Item_ID);

DROP TRIGGER IF EXISTS trgInventory_Specs_Date_Ins on Inventory_Specs_Date;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_Date_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Inventory_Specs_Date
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgInventory_Specs_Date_upd on Inventory_Specs_Date;
---------------------------------------------------------------------------
CREATE TRIGGER trgInventory_Specs_Date_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Inventory_Specs_Date
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

  INSERT into Account_Inventory(
      UUID, Account_ID, Item_Name, Generic_Name_ID, Brand_Name_ID, Supplier_ID, 
      Inventory, Unit_Price , Book_Value , Unit, Measure_ID, Discount, Tax_Rate, Remarks)
  
  SELECT 
      cast(Acc.UUID as UUID), a.ID Account_ID, Acc.Item_Name, gen.ID Generic_Name_ID, 
      bn.ID Brand_Name_ID, supl.ID Supplier_ID, 
      Acc.Inventory, Acc.Unit_Price , Book_Value , Acc.Unit, uc.ID Measure_ID, Acc.Discount, Tax_Rate, Acc.Remarks
  FROM (Values
      ('c3476afe-bd50-49e6-8de3-074555a8e1bd', '1001-0001-0000001', 'Colgate Ultra', 'Tooth Paste', 'Colgate', '10011', 25, 110, 2750, 25, 'ML', 0, .12, 'Test Product'),
      ('b35e39e8-885b-41a6-a070-a249c2a099e5', '1001-0001-0000001', 'Colgate White', 'Tooth Paste', 'Colgate', '10011', 25, 110, 2750, 25, 'ML', 0, .12, 'Test Product')
    )   
    Acc(
      UUID, Alternate_Acc, Item_Name, Generic_Name , Brand_Name , Supplier_altid, 
      Inventory, Unit_Price , Book_Value , Unit, measure, Discount, Tax_Rate, Remarks
      )
  LEFT JOIN Account a on a.Alternate_Acc = Acc.Alternate_Acc 
  LEFT JOIN vwReference gen on gen.Title = Acc.Generic_Name  and gen.Ref_Type = 'GenericName '
  LEFT JOIN vwReference bn on bn.Title = Acc.Brand_Name  and bn.Ref_Type = 'BrandName'
  LEFT JOIN vwReference uc on uc.Short_Name = Acc.measure and uc.Ref_Type = 'UnitMeasure'
  LEFT JOIN Customer supl on supl.Customer_Alt_ID = Supplier_altid
  
  --select * from vwReference v2 where Title = 'Colgate' and Ref_Type = 'Brand_Name '
  ON CONFLICT(UUID) DO UPDATE SET
    Item_Name = excluded.Item_Name,
    Generic_Name_ID = excluded.Generic_Name_ID,
    Brand_Name_ID = excluded.Brand_Name_ID,
    Supplier_ID = excluded.Supplier_ID,
    Inventory = excluded.Inventory,
    Unit_Price  = excluded.Unit_Price ,
    Unit = excluded.Unit,
    Measure_ID = excluded.Measure_ID,
    Discount = excluded.Discount,
    Tax_Rate = excluded.Tax_Rate,
    Remarks = excluded.Remarks
    ;

 