---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Account_Tran (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Trn_Head_ID bigint NOT NULL,
  Series bigint NOT NULL,
  Value_Date Date NOT NULL,
  Account_ID bigint NOT NULL,
  Currency varchar(3) NOT NULL,
  Item_ID bigint NULL,
  Passbook_Posted bool NOT NULL,
  Trn_Prin numeric(16,6) NOT NULL DEFAULT 0,
  Trn_Int numeric(16,6) NOT NULL DEFAULT 0,
  Other_Info jsonb NULL,
  
  CONSTRAINT Account_Tran_pkey PRIMARY KEY (Trn_Head_ID, Series),
  CONSTRAINT fkAccount_TranTrn_Head FOREIGN KEY (Trn_Head_ID) REFERENCES Trn_Head(ID),
  CONSTRAINT fkAccount_TranAccount FOREIGN KEY (Account_ID) REFERENCES Account(ID),
  CONSTRAINT fkAccount_TranItem FOREIGN KEY (Item_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccount_Tran_UUID ON public.Account_Tran(UUID);

DROP TRIGGER IF EXISTS trgAccount_TranIns on Account_Tran;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_TranIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Account_Tran
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();

DROP TRIGGER IF EXISTS trgAccount_Tranupd on Account_Tran;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Tranupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Account_Tran
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();


  INSERT INTO Account_Tran(
    Trn_Head_ID, Series, Value_Date, Account_ID, Currency, Item_ID, Passbook_Posted, Trn_Prin, Trn_Int)
  SELECT 
    h.ID Trn_Head_ID, a.Series, Value_Date, Acc.ID Account_ID, a.Currency, i.ID Item_ID, Passbook_Posted, Trn_Prin, Trn_Int
    
   FROM (Values
      ('2af90d74-3bee-48c5-8935-443edafb8f5a'::UUID, 1, '01-01-2020'::Date, '1001-0001-0000001',  'PHP', 'General Assembly Meeting', TRUE, 0, 0)
      )   
    a(Trn_HeadUUID, Series, Value_Date, Alternate_Acc, Currency, Item, Passbook_Posted, Trn_Prin, Trn_Int)  

  LEFT JOIN Trn_Head h on h.UUID = a.Trn_HeadUUID
  LEFT JOIN vwReference i    on lower(i.Title) = lower(a.Item) and lower(i.Ref_Type) = 'churchfunditem'
  LEFT JOIN Account Acc      on Acc.Alternate_Acc = a.Alternate_Acc

  ON CONFLICT(Trn_Head_ID, Series)
  DO UPDATE SET
    Value_Date = excluded.Value_Date,
    Trn_Head_ID = excluded.Trn_Head_ID,
    Account_ID = excluded.Account_ID,
    Currency = excluded.Currency,
    Passbook_Posted = excluded.Passbook_Posted,
    Trn_Prin = excluded.Trn_Prin,
    Trn_Int = excluded.Trn_Int
  ;   
