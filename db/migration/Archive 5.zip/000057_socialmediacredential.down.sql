DROP TABLE IF EXISTS Social_Media_Credential cascade;
DROP TYPE IF EXISTS Social_Provider_Type;