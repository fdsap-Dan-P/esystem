DROP TABLE IF EXISTS Account_Inventory cascade;
