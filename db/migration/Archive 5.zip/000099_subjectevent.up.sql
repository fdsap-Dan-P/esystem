---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Subject_Event (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Type_ID bigint NOT NULL,
  Action_Ticket_ID bigint NOT NULL,
  IIID bigint NOT NULL,
  Section_Subject_ID bigint NULL,
  Event_Date Date NOT NULL, 
  Grading_Period SmallInt NOT NULL DEFAULT 0, -- (0-N/A, 1,2,3,4 Qtr, 10-Finals)
  Item_Count Numeric(8,5) NOT NULL DEFAULT 0,
  Status_ID bigint NOT NULL,
  Remarks varchar(200) NULL,
  Other_Info jsonb NULL,
 
  CONSTRAINT Subject_Event_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Subject_Event_iiid FOREIGN KEY (IIID) REFERENCES Identity_Info(ID),
  CONSTRAINT fk_Subject_Event_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Subject_Event_Ticket FOREIGN KEY (Action_Ticket_ID) REFERENCES Action_Ticket(ID),
  CONSTRAINT fk_Subject_Event_Subject FOREIGN KEY (Section_Subject_ID) REFERENCES Section_Subject(ID),
  CONSTRAINT fk_Subject_Event_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxSubject_Event_UUID ON public.Subject_Event(UUID);

DROP TRIGGER IF EXISTS trgSubject_Event_Ins on Subject_Event;
---------------------------------------------------------------------------
CREATE TRIGGER trgSubject_Event_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Subject_Event
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgSubject_Event_upd on Subject_Event;
---------------------------------------------------------------------------
CREATE TRIGGER trgSubject_Event_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Subject_Event
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgSubject_Event_del on Subject_Event;
---------------------------------------------------------------------------
CREATE TRIGGER trgSubject_Event_del
---------------------------------------------------------------------------
    AFTER DELETE ON Subject_Event
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
    INSERT into Subject_Event(
    UUID, Type_ID, Action_Ticket_ID, IIID, Section_Subject_ID, Event_Date,
    Grading_Period, Item_Count, Status_ID, Remarks
    ) 
 
  SELECT
    a.UUID, typ.ID Type_ID, tic.ID Action_Ticket_ID, ii.ID IIID, sec.ID Section_Subject_ID, a.Event_Date,
    a.Grading_Period, a.Item_Count, stat.ID Status_ID, a.Remarks
  FROM (Values
      ('75c261eb-e4c3-4fbb-8173-ccf3f803c1b6'::UUID, 'Written Works', '100', '8ac29dea-7e8b-43a1-a2de-c85b39f4372c'::UUID, 'ed6a63f9-44bd-4aef-87ed-8e5538f392f8'::UUID, '2022-01-01'::date, 1, 20, 'Completed', 'Remarks')
      )   
  a(
    UUID, EventType, Alternate_ID, Action_Ticket_UUID, Section_Subject_UUID, Event_Date,
    Grading_Period, Item_Count, Status, Remarks
    )
    
  LEFT JOIN vwReference typ  on lower(typ.Title) = lower(a.EventType) and lower(typ.Ref_Type) = lower('SubjectEvent')
  LEFT JOIN Action_Ticket tic on tic.UUID = a.Action_Ticket_UUID
  LEFT JOIN Identity_Info ii on ii.Alternate_ID = a.Alternate_ID
  LEFT JOIN Section_Subject sec on sec.UUID = a.Section_Subject_UUID
  LEFT JOIN vwReference stat on stat.Title = a.Status and stat.Ref_Type = 'SubjectStatus'
  
  ON CONFLICT(UUID) DO UPDATE SET
    Type_ID = excluded.Type_ID,
    Action_Ticket_ID = excluded.Action_Ticket_ID,
    IIID = excluded.IIID,
    Section_Subject_ID = excluded.Section_Subject_ID,
    Event_Date = excluded.Event_Date,
    Grading_Period = excluded.Grading_Period,
    Item_Count = excluded.Item_Count,
    Status_ID = excluded.Status_ID,
    Remarks = excluded.Remarks
  ;
