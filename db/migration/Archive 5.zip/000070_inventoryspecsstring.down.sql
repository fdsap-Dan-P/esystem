DROP TABLE IF EXISTS Inventory_Specs_String cascade;
