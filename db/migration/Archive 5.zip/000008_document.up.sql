---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Documents (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Doc_Date Date NULL,
  File_Path varchar(1000) NOT NULL,
  Thumbnail bytea NULL,
  DocType_ID bigint NULL,
  Storage_ID bigint NULL,
  Secret_Key varchar(255) NULL,
  Description varchar(1000) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT documents_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_documents_Storage FOREIGN KEY (Storage_ID) REFERENCES Storage(ID),
  CONSTRAINT fk_documents_Type FOREIGN KEY (DocType_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxdocuments_UUID ON public.Documents(UUID);

DROP TRIGGER IF EXISTS trgdocuments_Ins on Documents;
---------------------------------------------------------------------------
CREATE TRIGGER trgdocuments_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Documents
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgdocuments_upd on Documents;
---------------------------------------------------------------------------
CREATE TRIGGER trgdocuments_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Documents
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();
---------------------------------------------------------------------------

DROP TRIGGER IF EXISTS trgDocuments_del on Documents;
---------------------------------------------------------------------------
CREATE TRIGGER trgDocuments_del
---------------------------------------------------------------------------
    AFTER DELETE ON Documents
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();

  INSERT INTO Documents(
    UUID, Doc_Date, File_Path, Thumbnail, DocType_ID, Storage_ID, Description)
  SELECT 
    a.UUID, a.Doc_Date, a.File_Path, a.Thumbnail, d.ID DocType_ID, s.ID Storage_ID, a.Description
    
   FROM (Values
      ('58f7c21a-0f52-401e-912a-e3b7edc63d62'::UUID, '12/21/2020'::date, 'pict.jpg', NULL::bytea, 'Profile Picture', 'bb295886-65ba-435d-a937-18fb9bd3204b'::UUID,'Roderick Mercado Profile Picture')
      )   
    a(UUID, Doc_Date, File_Path, Thumbnail, DocType, StorageUUID, Description)  

  INNER JOIN Storage s on s.UUID = a.StorageUUID
  LEFT JOIN vwReference d     on lower(d.Title) = lower(DocType) and lower(d.Ref_Type) = 'documenttype'
  
  ON CONFLICT(UUID)
  DO UPDATE SET
    Doc_Date = excluded.Doc_Date,
    File_Path = excluded.File_Path,
    Thumbnail = excluded.Thumbnail,
    DocType_ID = excluded.DocType_ID,
    Storage_ID = excluded.Storage_ID,
    Description = excluded.Description
  ;  
