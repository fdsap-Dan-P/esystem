DROP TABLE IF EXISTS entries cascade;
DROP TABLE IF EXISTS transfers cascade;
DROP TABLE IF EXISTS owner cascade;
DROP TABLE IF EXISTS account cascade;
