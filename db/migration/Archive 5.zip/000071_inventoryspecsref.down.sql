DROP TABLE IF EXISTS Inventory_Specs_Ref cascade;
