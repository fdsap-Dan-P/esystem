DROP TABLE IF EXISTS Identity_Info cascade;
DROP FUNCTION IF EXISTS identityinfoinsert cascade;
DROP FUNCTION IF EXISTS identityinfoupdate cascade;