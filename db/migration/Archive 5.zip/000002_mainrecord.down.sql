DROP TABLE IF EXISTS Main_Record cascade;
DROP TABLE IF EXISTS Modified cascade;
