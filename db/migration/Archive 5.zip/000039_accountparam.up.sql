---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.AccountParam (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Item_ID bigint NOT NULL,
  Type_ID bigint NOT NULL,
  Date_Implemented Date NOT NULL,
  Value_Int int8 NULL,
  Value_Decimal float8 NULL,
  Value_Date Date NULL,
  Value_String varchar(1000) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT AccountParam_pkey PRIMARY KEY (UUID),
  CONSTRAINT idxAccountParamID UNIQUE (Type_ID, Item_ID, Date_Implemented),
  CONSTRAINT fk_AccountParam_Reference FOREIGN KEY (Item_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_AccountParam_Account_Type FOREIGN KEY (Type_ID) REFERENCES Account_Type(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccountParam_UUID ON public.AccountParam(UUID);

DROP TRIGGER IF EXISTS trgAccountParam_Ins on AccountParam;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccountParam_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON AccountParam
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccountParam_upd on AccountParam;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccountParam_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON AccountParam
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAccountParam_del on AccountParam;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccountParam_del
---------------------------------------------------------------------------
    AFTER DELETE ON AccountParam
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


--------------------------------------------
-- CREATE AccountParam View
--------------------------------------------
CREATE OR REPLACE VIEW public.vwAccountParam
AS SELECT 
    mr.UUID,
        
    Date_Implemented,
    rf.Value_Int, rf.Value_Decimal, rf.Value_Date, rf.Value_String,
    
    
    par.ID Item_ID, par.UUID Param_ItemUUID, par.Title param_Item,
    y.ID Type_ID, y.UUID Account_TypeUUID, y.Account_Type,
    
    mr.Mod_Ctr,
    rf.Other_Info,
    mr.Created,
    mr.Updated 
   FROM AccountParam rf
     INNER JOIN Main_Record mr on mr.UUID = rf.UUID
     LEFT JOIN Reference par ON rf.Item_ID = par.ID
     LEFT JOIN Account_Type y ON y.ID = rf.Type_ID;

--------------------------------------------
    INSERT into AccountParam(
      Type_ID, Item_ID, Date_Implemented, 
      Value_Int, Value_Decimal, Value_Date, Value_String)     
    SELECT y.ID Type_ID, par.ID Item_ID, cast(a.Date_Implemented as Date), 
      a.Value_Int, cast(a.Value_Decimal as decimal), cast(a.Value_Date as Date), a.Value_String
    FROM (Values
        ('Sikap 1', 'Interest', '2010-10-01',
         30, null, null, null))
        a(Account_Type, param_Item, Date_Implemented, 
          Value_Int, Value_Decimal, Value_Date, Value_String)
    LEFT JOIN vwReference par on par.Ref_Type = 'Parameter' and par.Title = a.param_Item
    INNER JOIN Account_Type y on y.Account_Type = a.Account_Type
    LEFT JOIN AccountParam p on par.ID = p.Item_ID and y.ID = p.Type_ID 
    
    ON CONFLICT(Type_ID, Item_ID, Date_Implemented) DO UPDATE SET
      Date_Implemented  = EXCLUDED.Date_Implemented, 
      Value_Int = EXCLUDED.Value_Int, 
      Value_Decimal = EXCLUDED.Value_Decimal, 
      Value_Date = EXCLUDED.Value_Date, 
      Value_String = EXCLUDED.Value_String 
    ;
