---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Course_Offer (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Office_ID bigint NOT NULL,
  Course_ID bigint NOT NULL,
  Semister_ID bigint NOT NULL,
  Start_Date Date NULL NULL,
  Adviser_ID bigint NULL,
  Status_ID bigint NULL,
  Section_Name VarChar(100) NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Course_Offer_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Course_Offer_Office FOREIGN KEY (Office_ID) REFERENCES Office(ID),
  CONSTRAINT fk_Course_Offer_Course FOREIGN KEY (Course_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Course_Offer_Semister FOREIGN KEY (Semister_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Course_Offer_Adviser FOREIGN KEY (Adviser_ID) REFERENCES Employee(ID),
  CONSTRAINT fk_Course_Offer_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxCourse_Offer_UUID ON public.Course_Offer(UUID);
CREATE INDEX IF NOT EXISTS idxCourse_Offer_Section ON public.Course_Offer(Lower(Section_Name));

DROP TRIGGER IF EXISTS trgCourse_Offer_Ins on Course_Offer;
---------------------------------------------------------------------------
CREATE TRIGGER trgCourse_Offer_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Course_Offer
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgCourse_Offer_upd on Course_Offer;
---------------------------------------------------------------------------
CREATE TRIGGER trgCourse_Offer_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Course_Offer
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgCourse_Offer_del on Course_Offer;
---------------------------------------------------------------------------
CREATE TRIGGER trgCourse_Offer_del
---------------------------------------------------------------------------
    AFTER DELETE ON Course_Offer
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
  INSERT into Course_Offer(
    UUID, Office_ID, Course_ID, Semister_ID, Start_Date, Adviser_ID, 
    Status_ID, Section_Name, Remarks
    )
  SELECT
   a.UUID::UUID, o.ID Office_ID, cors.ID Course_ID, sem.id Semister_ID, a.Start_Date::date, adviser.ID Adviser_ID, 
    stat.ID Status_ID, Section_Name, Remarks
  FROM (Values
      ('3bdd00c6-dffb-4b7b-9b02-bf358205a690', '10019', 'Elementary', 'Full Year', '06/05/2022', '10001','97-0114', 'Current', 'Section A', 'Batch 2020')
      )   
  a(UUID, Office_altid, Course, Semister, Start_Date, CentralAlt, Employee_No, Status, Section_Name, Remarks)
    
  LEFT JOIN Office Cen  on lower(Cen.Alternate_ID) = lower(a.CentralAlt)  
  LEFT JOIN vwReference cors on lower(cors.Title) = lower(a.Course) and lower(cors.Ref_Type) = lower('CourseType')
  LEFT JOIN vwReference sem on lower(sem.Title) = lower(a.Semister) and lower(sem.Ref_Type) = lower('SchoolSemister')
  LEFT JOIN Office o on lower(o.Alternate_ID) = lower(a.Office_altid)
  LEFT JOIN Employee adviser on lower(adviser.Employee_No) = lower(a.Employee_No) 
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('CourseStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Office_ID = excluded.Office_ID, 
    Course_ID = excluded.Course_ID,
    Semister_ID = excluded.Semister_ID, 
    Start_Date = excluded.Start_Date, 
    Adviser_ID = excluded.Adviser_ID, 
    Status_ID = excluded.Status_ID, 
    Section_Name = excluded.Section_Name, 
    Remarks = excluded.Remarks
  ;
