DROP TABLE IF EXISTS Inventory_Specs_Date cascade;
