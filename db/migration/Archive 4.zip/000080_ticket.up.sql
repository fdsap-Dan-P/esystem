---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_Date  timestamptz NULL,
  Ticket_Type_ID bigint NOT NULL,
  Postedby_ID bigint NOT NULL,
  Status_ID bigint NOT NULL,
  Remarks varchar(100) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Ticket_pkey PRIMARY KEY (ID),
  CONSTRAINT fkTicket_Type FOREIGN KEY (Ticket_Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fkTicketUserName FOREIGN KEY (Postedby_ID) REFERENCES Users(ID),
  CONSTRAINT fkTicketStatus FOREIGN KEY (Status_ID ) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_UUID ON public.Ticket(UUID);

DROP TRIGGER IF EXISTS trgTicketIns on Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicketIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Ticket
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTicketupd on Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicketupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Ticket
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTicket_del on Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_del
---------------------------------------------------------------------------
    AFTER DELETE ON Ticket
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


  INSERT INTO Ticket(
    UUID, Ticket_Date , Ticket_Type_ID, Postedby_ID, Status_ID , Remarks)
  SELECT 
    cast(a.UUID as UUID), cast(a.Ticket_Date  as Date), tic.ID Ticket_Type_ID, 
    ul.ID Postedby_ID, sta.ID Status_ID , a.Remarks
    
   FROM (Values
      ('da970ce4-dc2f-44af-b1a8-49a987148922','01-01-2020','Over the Counter','erick1421@gmail.com', 'Completed', '')
      )   
    a(UUID, Ticket_Date , Ticket_Type, Postedby, Status, Remarks)  

  LEFT JOIN vwReference tic     on lower(tic.Title) = lower(Ticket_Type) and lower(tic.Ref_Type) = 'tickettype'
  LEFT JOIN vwReference sta     on lower(sta.Title) = lower(a.Status) and lower(sta.Ref_Type) = 'ticketstatus'
  LEFT JOIN Users ul        on lower(Login_Name) = lower(Postedby) 
  
  ON CONFLICT(UUID)
  DO UPDATE SET
    Ticket_Date  = excluded.Ticket_Date ,
    Ticket_Type_ID = excluded.Ticket_Type_ID,
    Postedby_ID = excluded.Postedby_ID,
    Status_ID  = excluded.Status_ID ,
    Remarks = excluded.Remarks
  ;  
