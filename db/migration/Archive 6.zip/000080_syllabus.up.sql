---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Syllabus (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Course_ID bigint NOT NULL,
  Version varchar(20) NOT NULL,
  Course_Year smallint NOT NULL,
  Semister_ID bigint NOT NULL,
  Status_ID bigint NULL,
  Date_Implement Date NOT NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Syllabus_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Syllabus_Course FOREIGN KEY (Course_ID) REFERENCES Course(ID),
  CONSTRAINT fk_Syllabus_Semister FOREIGN KEY (Semister_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Syllabus_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxSyllabus_UUID ON public.Syllabus(UUID);
CREATE INDEX IF NOT EXISTS idxSyllabus_Cors ON public.Syllabus(Course_ID);

DROP TRIGGER IF EXISTS trgSyllabus_Ins on Syllabus;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Syllabus
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgSyllabus_upd on Syllabus;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Syllabus
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgSyllabus_del on Syllabus;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_del
---------------------------------------------------------------------------
    AFTER DELETE ON Syllabus
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
    
  INSERT into Syllabus(
    UUID, Course_ID, Version, Course_Year, Semister_ID, Status_ID, 
    Date_Implement, Remarks
    )
  SELECT
   a.UUID, cors.ID Course_ID, Version, Course_Year, sem.ID Semister_ID,
   stat.ID Status_ID, Date_Implement, a.Remarks
  FROM (Values
      ('034ae2f0-ff93-405d-a7cf-0983750a6ed9'::UUID, '8845d46a-c910-4467-a40b-37008c78a288'::UUID, '2001', 1, 'Full Year', 'Current', '06/05/2001'::Date, 'Elementary English')
      )   
    a(UUID, Course, Version, Course_Year, Semister, Status, Date_Implement, Remarks)
    
  LEFT JOIN Course cors on a.Course = cors.UUID
  LEFT JOIN vwReference sem on lower(sem.Title) = lower(a.Semister) and lower(sem.Ref_Type) = lower('SchoolSemister')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('SubjectStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Course_ID = excluded.Course_ID,
    Version = excluded.Version, 
    Course_Year = excluded.Course_Year, 
    Semister_ID = excluded.Semister_ID, 
    Status_ID = excluded.Status_ID, 
    Date_Implement = excluded.Date_Implement, 
    Remarks = excluded.Remarks
  ;

---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Syllabus_Subject (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Syllabus_ID bigint NOT NULL,
  Subject_ID bigint NOT NULL,
  Units smallInt NOT NULL,
  Type_ID bigint NULL,
  Status_ID bigint NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Syllabus_Subject_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Syllabus_Subject_Syllabus FOREIGN KEY (Subject_ID) REFERENCES Syllabus(ID),
  CONSTRAINT fk_Syllabus_Subject_Subject FOREIGN KEY (Subject_ID) REFERENCES Subject(ID),
  CONSTRAINT fk_Subject_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Syllabus_Subject_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxSyllabus_Subject_UUID ON public.Syllabus_Subject(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxSyllabus_Subject_Syllabus ON public.Syllabus_Subject(Syllabus_ID, Subject_ID);

DROP TRIGGER IF EXISTS trgSyllabus_Subject_Ins on Syllabus_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_Subject_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Syllabus_Subject
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgSyllabus_Subject_upd on Syllabus_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_Subject_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Syllabus_Subject
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgSyllabus_Subject_del on Syllabus_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSyllabus_Subject_del
---------------------------------------------------------------------------
    AFTER DELETE ON Syllabus_Subject
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();

  INSERT into Syllabus_Subject(
    UUID, Syllabus_ID, Subject_ID, Units, Type_ID, Status_ID, Remarks
    )
  SELECT
   a.UUID, sy.ID Syllabus_ID, subj.ID Subject_ID, Units, typ.ID Type_ID, stat.ID Status_ID, a.Remarks
  FROM (Values
      ('1d05a01a-a531-42e2-aac6-c423199cee0f'::UUID, '034ae2f0-ff93-405d-a7cf-0983750a6ed9'::UUID, '945b7370-d414-4a6c-9533-3e2d1337cf5f'::UUID, 3, 'Regular', 'Current', 'Elementary English')
      )   
    a(UUID, Syllabus, Subject, Units, Subject_Type, Status, Remarks)
    
  LEFT JOIN Syllabus sy on a.Syllabus = sy.UUID
  LEFT JOIN Subject subj on a.Subject = subj.UUID
  LEFT JOIN vwReference typ on lower(typ.Title) = lower(a.Subject_Type) and lower(typ.Ref_Type) = lower('SubjectType')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('SubjectStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Syllabus_ID = excluded.Syllabus_ID,
    Subject_ID = excluded.Subject_ID, 
    Units = excluded.Units,
    Type_ID = excluded.Type_ID, 
    Status_ID = excluded.Status_ID, 
    Remarks = excluded.Remarks
  ;
