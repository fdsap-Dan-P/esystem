---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Trn_Action (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Trn_Head_ID bigint NOT NULL,
  Type_ID bigint NOT NULL,
  User_ID bigint NOT NULL,
  Trn_Action_Date timestamptz NULL,
  Reference varchar(20) NULL,
  Remarks varchar(100) NULL,
  Other_Info jsonb NULL,
  CONSTRAINT Trn_Action_pkey PRIMARY KEY (UUID),
  CONSTRAINT fkTrn_ActionTrn FOREIGN KEY (Trn_Head_ID) REFERENCES Trn_Head(ID),
  CONSTRAINT fkTrn_ActionType FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fkTrn_ActionUserName FOREIGN KEY (User_ID) REFERENCES Users(ID)
);

DROP TRIGGER IF EXISTS trgTrn_ActionIns on Trn_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_ActionIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Trn_Action
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTrn_Actionupd on Trn_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Actionupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Trn_Action
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTrn_Action_del on Trn_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Action_del
---------------------------------------------------------------------------
    AFTER DELETE ON Trn_Action
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


  INSERT INTO Trn_Action(
    UUID, Trn_Head_ID, Type_ID, User_ID, Trn_Action_Date, Reference, Remarks)
  SELECT 
    a.UUID, h.ID Trn_Head_ID,
    typ.ID Type_ID, ul.ID User_ID, cast(a.Trn_Action_Date as Date), a.Reference, a.Remarks
    
   FROM (Values
      ('533a7da7-5376-4e76-a3bc-2f61e49dd462'::UUID, '2af90d74-3bee-48c5-8935-443edafb8f5a'::UUID,'Posted','erick1421@gmail.com', '01/01/2020', 'ref', 'test')
      )   
    a(UUID, Trn_HeadUUID, Trn_ActionType, Login_Name, Trn_Action_Date, Reference, Remarks)  

  INNER JOIN Trn_Head h on h.UUID = a.Trn_HeadUUID
  LEFT JOIN vwReference typ  on lower(typ.Title) = lower(a.Trn_ActionType) and lower(typ.Ref_Type) = 'actionlist'
  LEFT JOIN Users ul     on lower(ul.Login_Name) = lower(a.Login_Name) 
  
  ON CONFLICT(UUID)
  DO UPDATE SET
    Trn_Head_ID = excluded.Trn_Head_ID,
    Type_ID = excluded.Type_ID,
    User_ID = excluded.User_ID,
    Trn_Action_Date = excluded.Trn_Action_Date,
    Reference = excluded.Reference,
    Remarks = excluded.Remarks
  ;   
