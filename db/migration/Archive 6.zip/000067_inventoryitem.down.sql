DROP TABLE IF EXISTS Inventory_Item cascade;
