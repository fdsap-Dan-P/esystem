---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Action_List (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_ID bigint NOT NULL,
  Action_ID bigint NOT NULL,
  Status_ID bigint NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Action_List_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Action_List_Ticket FOREIGN KEY (Ticket_ID) REFERENCES Ticket(ID),
  CONSTRAINT fk_Action_List_Action FOREIGN KEY (Action_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Action_List_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAction_List_UUID ON public.Action_List(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxAction_List_Subject ON public.Action_List(Ticket_ID, Action_ID);

DROP TRIGGER IF EXISTS trgAction_List_Ins on Action_List;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_List_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Action_List
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAction_List_upd on Action_List;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_List_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Action_List
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAction_List_del on Action_List;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_List_del
---------------------------------------------------------------------------
    AFTER DELETE ON Action_List
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
  INSERT into Action_List(
    UUID, Ticket_ID, Action_ID, Status_ID, Remarks
    )
  SELECT
    a.UUID, tic.ID Ticket_ID, act.ID Action_ID, stat.ID Status_ID, Remarks
  FROM (Values
      ('c03d8bd1-1fc7-4e2f-984b-a80e4c01c4e0'::UUID, 'ecd7915c-4335-43a2-b2fa-b361cb125b6e'::UUID, 'Encoded', 'Active','Remarks for Action List')
      )   
    a(UUID, Ticket_UUID, Action, Status, Remarks)   
  LEFT JOIN Ticket_Type tic on a.Ticket_UUID = tic.UUID
  LEFT JOIN vwReference act on lower(act.Title) = lower(a.Action) and lower(act.Ref_Type) = lower('ActionList')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('ActionListStatus')
    
  ON CONFLICT(UUID) DO UPDATE SET
    Ticket_ID = excluded.Ticket_ID,
    Action_ID = excluded.Action_ID,
    Status_ID = excluded.Status_ID, 
    Remarks = excluded.Remarks;

