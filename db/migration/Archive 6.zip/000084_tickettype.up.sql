
---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket_Type (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Product_ID bigint NOT NULL,
  Group_ID bigint NOT NULL,
  Type_ID bigint NOT NULL,
  Title Varchar(200) NOT NULL,
  Status_ID bigint NULL,
  Other_Info jsonb NULL,
 
  CONSTRAINT Ticket_Type_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Ticket_Type_Product FOREIGN KEY (Product_ID) REFERENCES Product(ID),
  CONSTRAINT fk_Ticket_Type_Group FOREIGN KEY (Group_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Ticket_Type_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID)
);

CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Type_UUID ON public.Ticket_Type(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Type_Unq ON public.Ticket_Type(Product_ID, Group_ID, Type_ID);

DROP TRIGGER IF EXISTS trgTicket_Type_Ins on Ticket_Type;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Type_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Ticket_Type
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTicket_Type_upd on Ticket_Type;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Type_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Ticket_Type
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTicket_Type_del on Ticket_Type;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Type_del
---------------------------------------------------------------------------
    AFTER DELETE ON Ticket_Type
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();

  INSERT into Ticket_Type(
    UUID, Product_ID, Group_ID, Type_ID, Title, Status_ID
    )
  SELECT
    a.UUID, prod.ID Product_ID, grp.ID Group_ID, typ.ID Type_ID, typ.Title, stat.ID Status_ID
    
  FROM (Values
      ('ecd7915c-4335-43a2-b2fa-b361cb125b6e'::UUID, 'School', 'Regular', 'Enrollment', 'Current')
      )   
    a(UUID, Product, Grp, TicketType, Status)
     
  LEFT JOIN Product prod on lower(prod.Product_Name) = lower(a.Product)
  LEFT JOIN vwReference grp on lower(grp.Title) = lower(a.Grp) and lower(grp.Ref_Type) = lower('SchoolGroup')
  LEFT JOIN vwReference typ on lower(typ.Title) = lower(a.TicketType) and lower(typ.Ref_Type) = lower('TicketType')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('SubjectStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Product_ID = excluded.Product_ID,
    Group_ID = excluded.Group_ID,
    Type_ID = excluded.Type_ID, 
    Title = excluded.Title,
    Status_ID = excluded.Status_ID
  ;
