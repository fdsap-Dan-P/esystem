
---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket_Flow (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Account_ID bigint NOT NULL,
  Section_Subject_ID bigint NOT NULL,
  Subject_ID bigint NOT NULL,
  Grade_1stQtr Numeric(8,5) NOT NULL DEFAULT 0,
  Grade_2ndQtr Numeric(8,5) NOT NULL DEFAULT 0,
  Grade_3rdQtr Numeric(8,5) NOT NULL DEFAULT 0,
  Grade_4thQtr Numeric(8,5) NOT NULL DEFAULT 0,
  Grade_Final  Numeric(8,5) NOT NULL DEFAULT 0,
  Attendance_Ctr Int NOT NULL DEFAULT 0,
  Absent_Ctr Int NOT NULL DEFAULT 0,
  Late_Ctr Int NOT NULL DEFAULT 0,
  Status_ID bigint NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Ticket_Flow_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Ticket_Flow_Acc FOREIGN KEY (Account_ID) REFERENCES Account(ID),
  CONSTRAINT fk_Ticket_Flow_SubjSection FOREIGN KEY (Section_Subject_ID) REFERENCES Section_Subject(ID),
  CONSTRAINT fk_Section_Subject_Subject FOREIGN KEY (Subject_ID) REFERENCES Subject(ID),
    CONSTRAINT fk_Ticket_Flow_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Flow_UUID ON public.Ticket_Flow(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Flow_Subject ON public.Ticket_Flow(Account_ID, Section_Subject_ID);

DROP TRIGGER IF EXISTS trgTicket_Flow_Ins on Ticket_Flow;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Flow_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Ticket_Flow
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTicket_Flow_upd on Ticket_Flow;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Flow_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Ticket_Flow
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTicket_Flow_del on Ticket_Flow;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Flow_del
---------------------------------------------------------------------------
    AFTER DELETE ON Ticket_Flow
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
  INSERT into Ticket_Flow(
    UUID, Account_ID, Section_Subject_ID, Subject_ID, Grade_1stQtr, Grade_2ndQtr, Grade_3rdQtr, Grade_4thQtr, Grade_Final,
    Attendance_Ctr, Absent_Ctr, Late_Ctr, Status_ID, Remarks
    )
  SELECT
    a.UUID, Acc.ID Account_ID, sec.ID Section_Subject_ID, subj.ID Subject_ID, 
    Grade_1stQtr, Grade_2ndQtr, Grade_3rdQtr, Grade_4thQtr, Grade_Final,
    Attendance_Ctr, Absent_Ctr, Late_Ctr, stat.ID Status_ID, a.Remarks
  FROM (Values
      ('a5641251-df65-48a0-a42b-85f90a0fcd5d'::UUID, '1001-0001-0000001', 'ed6a63f9-44bd-4aef-87ed-8e5538f392f8'::UUID, '945b7370-d414-4a6c-9533-3e2d1337cf5f'::UUID, 91,92,93,94, 92, 1,2,3, 'Current', 'Elementary English')
      )   
    a(UUID, Alternate_Acc, SectionSubject, Subject, Grade_1stQtr, Grade_2ndQtr, Grade_3rdQtr, Grade_4thQtr, Grade_Final,
      Attendance_Ctr, Absent_Ctr, Late_Ctr, Status, Remarks)
    
  LEFT JOIN Account Acc on a.Alternate_Acc = Acc.Alternate_Acc
  LEFT JOIN Section_Subject sec on a.SectionSubject = sec.UUID
  LEFT JOIN Subject subj on a.Subject = subj.UUID
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('SubjectStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Account_ID = excluded.Account_ID,
    Section_Subject_ID = excluded.Section_Subject_ID,
    Subject_ID = excluded.Subject_ID, 
    Grade_1stQtr = excluded.Grade_1stQtr,
    Grade_2ndQtr = excluded.Grade_2ndQtr, 
    Grade_3rdQtr = excluded.Grade_3rdQtr, 
    Grade_4thQtr = excluded.Grade_4thQtr, 
    Grade_Final = excluded.Grade_Final, 
    Attendance_Ctr = excluded.Attendance_Ctr, 
    Absent_Ctr = excluded.Absent_Ctr, 
    Late_Ctr = excluded.Late_Ctr, 
    Status_ID = excluded.Status_ID, 
    Remarks = excluded.Remarks
  ;

