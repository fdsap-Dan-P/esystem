----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Account_Quantity (
----------------------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Account_ID bigint NOT NULL,
  Package_ID bigint NULL,
  ItemName varchar(100) NOT NULL,
  Generic_Name_ID bigint NULL,
  Brand_Name_ID bigint NULL,
  Supplier_ID bigint NULL,
  Quantity numeric(16,6) NOT NULL,
  Unit_Price  numeric(16,6) NOT NULL, 
  Book_Value  numeric(16,6) NOT NULL,
  Unit numeric(16,6) NOT NULL,
  Measure_ID bigint NOT NULL,
  Discount numeric(10,6) NOT NULL, 
  Tax_Rate numeric(10,6) NOT NULL,
  Remarks varchar(1000) NOT NULL,
  Other_Info jsonb NULL,  
  
  CONSTRAINT Account_Quantity_pkey PRIMARY KEY (ID),
  CONSTRAINT Account_Quantity_ID FOREIGN KEY (Account_ID) REFERENCES Account(ID),
  CONSTRAINT Account_Quantity_pkg FOREIGN KEY (Package_ID) REFERENCES Account_Quantity(ID),
  CONSTRAINT fk_Account_Quantity_sup FOREIGN KEY (Supplier_ID) REFERENCES Customer(ID),
  CONSTRAINT fk_Account_Quantity_gen FOREIGN KEY (Generic_Name_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Account_Quantity_bn FOREIGN KEY (Brand_Name_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Account_Quantity_Unitmeasure FOREIGN KEY (Measure_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccount_Quantity_UUID ON public.Account_Quantity(UUID);

DROP TRIGGER IF EXISTS trgAccount_Quantity_Ins on Account_Quantity;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Quantity_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Account_Quantity
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccount_Quantity_upd on Account_Quantity;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Quantity_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Account_Quantity
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAccount_Quantity_del on Account_Quantity;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Quantity_del
---------------------------------------------------------------------------
    AFTER DELETE ON Account_Quantity
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


  INSERT into Account_Quantity(
      UUID, Account_ID, ItemName, Generic_Name_ID, Brand_Name_ID, Supplier_ID, 
      Quantity, Unit_Price , Book_Value , Unit, Measure_ID, Discount, Tax_Rate, Remarks)
  
  SELECT 
      cast(Acc.UUID as UUID), a.ID Account_ID, Acc.ItemName, gen.ID Generic_Name_ID, 
      bn.ID Brand_Name_ID, supl.ID Supplier_ID, 
      Acc.Quantity, Acc.Unit_Price , Book_Value , Acc.Unit, uc.ID Measure_ID, Acc.Discount, Tax_Rate, Acc.Remarks
  FROM (Values
      ('c3476afe-bd50-49e6-8de3-074555a8e1bd', '1001-0001-0000001', 'Colgate Ultra', 'Tooth Paste', 'Colgate', '10011', 25, 110, 2750, 25, 'ML', 0, .12, 'Test Product')
      )   
    Acc(
      UUID, Alternate_Acc, ItemName, Generic_Name , Brand_Name , Supplier_altid, 
      Quantity, Unit_Price , Book_Value , Unit, measure, Discount, Tax_Rate, Remarks
      )
  LEFT JOIN Account a on a.Alternate_Acc = Acc.Alternate_Acc 
  LEFT JOIN vwReference gen on gen.Title = Acc.Generic_Name  and gen.Ref_Type = 'Generic_Name '
  LEFT JOIN vwReference bn on bn.Title = Acc.Brand_Name  and bn.Ref_Type = 'Brand_Name '
  LEFT JOIN vwReference uc on uc.Short_Name = Acc.measure and uc.Ref_Type = 'UnitMeasure'
  LEFT JOIN Customer supl on supl.Customer_Alt_ID = Supplier_altid
  
  --select * from vwReference v2 where Title = 'Colgate' and Ref_Type = 'Brand_Name '
  ON CONFLICT(UUID) DO UPDATE SET
    ItemName = excluded.ItemName,
    Generic_Name_ID = excluded.Generic_Name_ID,
    Brand_Name_ID = excluded.Brand_Name_ID,
    Supplier_ID = excluded.Supplier_ID,
    Quantity = excluded.Quantity,
    Unit_Price  = excluded.Unit_Price ,
    Unit = excluded.Unit,
    Measure_ID = excluded.Measure_ID,
    Discount = excluded.Discount,
    Tax_Rate = excluded.Tax_Rate,
    Remarks = excluded.Remarks
    ;