DROP TABLE IF EXISTS geography cascade;
DROP FUNCTION IF EXISTS searchLocation;
DROP FUNCTION IF EXISTS Geography_INSERT cascade;
DROP FUNCTION IF EXISTS Geography_UPDATE cascade;
DROP FUNCTION IF EXISTS identityinfoinsert cascade;
DROP FUNCTION IF EXISTS identityinfoupdate cascade;
DROP FUNCTION IF EXISTS searchlocation cascade;
DROP FUNCTION IF EXISTS searchname cascade;
DROP FUNCTION IF EXISTS customergroup_update cascade;