CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
---------------------------------------------------------------------------
CREATE Sequence IF NOT EXISTS public.Mod_Ctr_seq
---------------------------------------------------------------------------
  INCREMENT BY 1
  MINValue 1
  MAXValue 9223372036854775807
  START 1
  CACHE 1
  NO CYCLE;

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Main_Record (
----------------------------------------------------------------------------------------
  UUID     uuid NOT NULL,
  Mod_Ctr   int8 NOT NULL,
  Tablename VarChar(255),
  Created  timestamptz NULL,
  Updated  timestamptz NULL,
  CONSTRAINT Main_Record_pkey PRIMARY KEY (UUID)
);

----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Modified (
----------------------------------------------------------------------------------------
  Mod_Ctr int8 NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  
  Updated timestamptz NULL,
  CONSTRAINT Modified_pkey PRIMARY KEY (Mod_Ctr),
  CONSTRAINT fkModifiedID FOREIGN KEY (UUID) REFERENCES Main_Record(UUID)
);

CREATE INDEX IF NOT EXISTS idxModified_UUID ON public.Modified(UUID);

-- INSERT Trigger
---------------------------------------------------------------------------
CREATE or REPLACE FUNCTION trgGenericInsert() returns trigger AS 
---------------------------------------------------------------------------
$$ 
DECLARE 
   ctr int8 := Nextval('Mod_Ctr_seq');
   upd timestamptz := CURRENT_TIMESTAMP;
   payload JSON;
BEGIN
   
   payload = json_build_object( 
      'action', TG_OP,
      'table',  TG_TABLE_NAME::regclass::text,
      'data',  json_build_object( 
          'UUID', NEW.UUID,
          'Mod_Ctr', ctr
      ) 
   );

   INSERT INTO Main_Record(UUID, TableName, Mod_Ctr, Created)
   SELECT NEW.UUID, TG_TABLE_NAME::regclass::text, ctr, upd
   ON CONFLICT DO NOTHING;  
 
   INSERT INTO Modified(Mod_Ctr, UUID, Updated)
   SELECT ctr, NEW.UUID, upd;

   PERFORM pg_notify('mychan', payload::text);
   
   RETURN NEW;
   
END $$ Language plpgsql;

-- UPDATE Trigger
---------------------------------------------------------------------------
CREATE or REPLACE FUNCTION trgGenericUpdate() returns trigger AS 
---------------------------------------------------------------------------
$$ 
DECLARE 
   ctr int8 := Nextval('Mod_Ctr_seq');
   Upd timestamptz := CURRENT_TIMESTAMP;
   payload JSON;
BEGIN
   
   payload = json_build_object( 
      'action', TG_OP,
      'table',  TG_TABLE_NAME::regclass::text,
      'data',  json_build_object( 
          'UUID', NEW.UUID,
          'Mod_Ctr', ctr
      ) 
   );

  INSERT INTO Main_Record(UUID, TableName, Mod_Ctr, Created)
  SELECT NEW.UUID, TG_TABLE_NAME::regclass::text, ctr, upd
  ON CONFLICT(UUID) DO 
  UPDATE SET Updated = Upd;    


  INSERT INTO Modified(Mod_Ctr, UUID, Updated)
  ValueS(ctr, NEW.UUID, upd);

--   UPDATE Main_Record 
--   SET Updated = Upd
--   WHERE UUID = NEW.UUID;

  PERFORM pg_notify('mychan', payload::text);
  RETURN NEW;
END $$ Language plpgsql;

---------------------------------------------------------------------------
CREATE or REPLACE FUNCTION trgGenericDelete() returns trigger AS 
---------------------------------------------------------------------------
$$ 
DECLARE 
   ctr int8 := Nextval('Mod_Ctr_seq');
   Upd timestamptz := CURRENT_TIMESTAMP;
   payload JSON;
BEGIN

  payload = json_build_object( 
       'action', TG_OP, 
       'data', json_build_object('UUID', OLD.UUID ) 
     );

  INSERT INTO Main_Record(UUID, TableName, Mod_Ctr, Created)
  SELECT NEW.UUID, TG_TABLE_NAME::regclass::text, ctr, upd
  ON CONFLICT(UUID) DO 
  UPDATE SET Updated = Upd;    
  
  INSERT INTO Modified(Mod_Ctr, UUID, Updated, Other_Info)
  ValueS(ctr, OLD.UUID, upd, row_to_json( NEW ));
     
  PERFORM pg_notify('mychan', payload::text);
  RETURN NULL;
END $$ Language plpgsql;
