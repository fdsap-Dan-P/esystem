---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Storage (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Code varchar(30) NOT NULL,
  Connectivity int2 NOT NULL, -- 0:local, 1:network, 2:service
  Net_Address varchar(100) NOT NULL,
  Certificate text,
  HomePath varchar(1000) NOT NULL DEFAULT '',
  Description varchar(1000) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Storage_pkey PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxStorage_UUID ON public.Storage(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxStorage_Code ON public.Storage(lower(Code));

DROP TRIGGER IF EXISTS trgStorage_Ins on Storage;
---------------------------------------------------------------------------
CREATE TRIGGER trgStorage_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Storage
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgStorage_upd on Storage;
---------------------------------------------------------------------------
CREATE TRIGGER trgStorage_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Storage
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgStorage_del on Storage;
---------------------------------------------------------------------------
CREATE TRIGGER trgStorage_del
---------------------------------------------------------------------------
    AFTER DELETE ON Storage
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();

INSERT INTO Storage(
    UUID, Code, Connectivity, Net_Address, Certificate, Description)
  SELECT 
    a.UUID, a.Code, 
    CASE a.Connectivity WHEN 'local' THEN 0 WHEN 'network' THEN 1 WHEN 'service' THEN 2 ELSE 0 END Connectivity, 
    a.Net_Address, a.Certificate, a.Description
    
   FROM (Values
      ('bb295886-65ba-435d-a937-18fb9bd3204b'::UUID,'Local','Local','localhost',NULL,'Local Storage')
      )   
    a( UUID, Code, Connectivity, Net_Address, Certificate, Description)  

  ON CONFLICT(lower(Code))
  DO UPDATE SET
    Connectivity = excluded.Connectivity,
    Net_Address = excluded.Net_Address,
    Certificate = excluded.Certificate,
    Description = excluded.Description
  ;  
