---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Trn_Head (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_ID bigint NOT NULL,
  Trn_Date Date NOT NULL,
  Trn bigint NOT NULL,
  Type_ID bigint NOT NULL,
  Office_ID bigint NOT NULL,
  User_ID bigint NOT NULL,
  Transacting_ID bigint NOT NULL,
  ORNo varchar(30) NULL,
  isFinal bool NULL,
  isManual bool NULL,
  Alternate_Trn varchar(30) NULL,
  Reference varchar(20) NOT NULL,
  Remarks varchar(100) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Trn_Head_pkey PRIMARY KEY (ID),
  CONSTRAINT Trn_HeadTrn UNIQUE (Trn_Date, Trn),
  CONSTRAINT Trn_HeadaltTrn UNIQUE (Alternate_Trn),
  CONSTRAINT Trn_Header UNIQUE (ORNo),
  CONSTRAINT fkTrn_Head_IDentity FOREIGN KEY (Transacting_ID) REFERENCES Identity_Info(ID),
  CONSTRAINT fkTrn_HeadOffice FOREIGN KEY (Office_ID ) REFERENCES Office(ID),
  CONSTRAINT fkTrn_HeadTrn_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fkTrn_HeadUserName FOREIGN KEY (User_ID) REFERENCES Users(ID),
  CONSTRAINT fkTrn_HeadTicket FOREIGN KEY (Ticket_ID) REFERENCES Ticket(ID)
); 
CREATE UNIQUE INDEX IF NOT EXISTS idxTrn_Head_UUID ON public.Trn_Head(UUID);

DROP TRIGGER IF EXISTS trgTrn_HeadIns on Trn_Head;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_HeadIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Trn_Head
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTrn_Headupd on Trn_Head;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Headupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Trn_Head
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTrn_Head_del on Trn_Head;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Head_del
---------------------------------------------------------------------------
    AFTER DELETE ON Trn_Head
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();

------------------------------------------------------ 
CREATE OR REPLACE VIEW vwTrn_Head AS
------------------------------------------------------ 
  SELECT
    th.ID, mr.UUID, th.Ticket_ID, th.Trn_Date, th.Trn, th.Type_ID, 
    th.Office_ID , th.User_ID, th.Transacting_ID, th.ORNo, th.isFinal, 
    th.isManual, th.Alternate_Trn, th.Reference, th.Remarks,

    mr.Mod_Ctr,
    th.Other_Info,
    mr.Created,
    mr.Updated 
    
  FROM Trn_Head th
  INNER JOIN Main_Record mr on th.UUID = mr.UUID
  INNER JOIN Ticket on Ticket.ID = th.Ticket_ID 
 ;

  INSERT INTO Trn_Head(
    UUID, Ticket_ID, Trn_Date, Trn, Type_ID, Office_ID , User_ID, 
    Transacting_ID, ORNo, isFinal, isManual, Alternate_Trn, Reference, Remarks)
  SELECT 
    a.UUID, T.ID Ticket_ID, cast(Trn_Date as Date), 
    a.Trn, typ.ID Type_ID, o.ID Office_ID , ul.ID User_ID, 
    ii.ID Transacting_ID, a.ORNo, a.isFinal, a.isManual, a.Alternate_Trn, a.Reference, a.Remarks
    
   FROM (Values
      ('2af90d74-3bee-48c5-8935-443edafb8f5a'::UUID, 'da970ce4-dc2f-44af-b1a8-49a987148922'::UUID,'01-01-2020', 1, 'Payment', '10019', 'erick1421@gmail.com', '10001', 20010, true, true, null, 'ref', 'Remarks'),
      ('26dfab18-f80b-46cf-9c54-be79d4fc5d23'::UUID, 'da970ce4-dc2f-44af-b1a8-49a987148922'::UUID,'01-01-2020', 2, 'Payment', '10019', 'erick1421@gmail.com', '10001', 20011, true, true, null, 'ref', 'Remarks'),
      ('3793422c-eb9f-49f0-9ec6-e5cf80caac25'::UUID, 'da970ce4-dc2f-44af-b1a8-49a987148922'::UUID,'01-01-2020', 3, 'Payment', '10019', 'erick1421@gmail.com', '10001', 20012, true, true, null, 'ref', 'Remarks')
      )   
    a(UUID, TicketUUID, Trn_Date, Trn, Trn_Type, Officealtid, Login_Name,  
      Transactingaltid, ORNo, isFinal, isManual, Alternate_Trn, Reference, Remarks)  

  LEFT JOIN vwReference typ  on lower(typ.Title) = lower(a.Trn_Type) and lower(typ.Ref_Type) = 'trntype'
  LEFT JOIN Ticket T on T.UUID = a.TicketUUID
  LEFT JOIN Users ul     on lower(ul.Login_Name) = lower(a.Login_Name) 
  LEFT JOIN Identity_Info ii on ii.Alternate_ID = a.Transactingaltid
  LEFT JOIN Office o         on lower(o.Alternate_ID) = lower(a.OfficeAltID) 
  
  ON CONFLICT(Trn_Date, Trn)
  DO UPDATE SET
    Trn_Date = excluded.Trn_Date,
    Trn = excluded.Trn,
    Type_ID = excluded.Type_ID,
    Office_ID  = excluded.Office_ID ,
    User_ID = excluded.User_ID,
    Transacting_ID = excluded.Transacting_ID,
    ORNo = excluded.ORNo,
    isFinal = excluded.isFinal,
    isManual = excluded.isManual,
    Alternate_Trn = excluded.Alternate_Trn,
    Reference = excluded.Reference,
    Remarks = excluded.Remarks
  ;   

