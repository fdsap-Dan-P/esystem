DROP TABLE IF EXISTS Inventory_Item cascade;
DROP TABLE IF EXISTS Account_Inventory cascade;
DROP TABLE IF EXISTS Inventory_Detail cascade;
DROP TABLE IF EXISTS Inventory_Specs_String cascade;
DROP TABLE IF EXISTS Inventory_Specs_Number cascade;
DROP TABLE IF EXISTS Inventory_Specs_Date cascade;
