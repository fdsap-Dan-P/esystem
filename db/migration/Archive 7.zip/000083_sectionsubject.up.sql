---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Section_Subject (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  School_Section_ID bigint NOT NULL,
  Subject_ID bigint NOT NULL,
  Teacher_ID bigint NULL,
  Type_ID bigint NULL,
  Status_ID bigint NULL,
  Schedule_Code VarChar(100) NULL,
  Schedule_Json jsonb NULL,
  Remarks Varchar(200) NOT NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Section_Subject_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Section_Subject_Section FOREIGN KEY (School_Section_ID) REFERENCES School_Section(ID),
  CONSTRAINT fk_Section_Subject_Subject FOREIGN KEY (Subject_ID) REFERENCES Subject(ID),
  CONSTRAINT fk_Section_Subject_Teacher FOREIGN KEY (Teacher_ID) REFERENCES Employee(ID),
  CONSTRAINT fk_Section_Subject_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Section_Subject_Status FOREIGN KEY (Status_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxSection_Subject_UUID ON public.Section_Subject(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxSection_Subject_Subject ON public.Section_Subject(School_Section_ID, Subject_ID);

DROP TRIGGER IF EXISTS trgSection_Subject_Ins on Section_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSection_Subject_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Section_Subject
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgSection_Subject_upd on Section_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSection_Subject_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Section_Subject
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgSection_Subject_del on Section_Subject;
---------------------------------------------------------------------------
CREATE TRIGGER trgSection_Subject_del
---------------------------------------------------------------------------
    AFTER DELETE ON Section_Subject
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
  INSERT into Section_Subject(
    UUID, Section_ID, Subject_ID, Teacher_ID, Type_ID, Status_ID, Schedule_Code, Remarks
    )
  SELECT
   a.UUID, sec.ID Section_ID, subj.ID Subject_ID, teach.ID Teacher_ID, 
   typ.ID Type_ID, stat.ID Status_ID, a.Schedule_Code, a.Remarks
  FROM (Values
      ('ed6a63f9-44bd-4aef-87ed-8e5538f392f8'::UUID, '3bdd00c6-dffb-4b7b-9b02-bf358205a690'::UUID, '945b7370-d414-4a6c-9533-3e2d1337cf5f'::UUID, '97-0114', 'Regular', 'Current', 'MWF 8-10am', 'Elementary English')
      )   
    a(UUID, Section, Subject, EmpNo, Subject_Type, Status, Schedule_Code, Remarks)
    
  LEFT JOIN School_Section sec on a.Section = sec.UUID
  LEFT JOIN Subject subj on a.Subject = subj.UUID
  LEFT JOIN Employee teach on lower(teach.Employee_No) = lower(a.EmpNo) 
  LEFT JOIN vwReference typ on lower(typ.Title) = lower(a.Subject_Type) and lower(typ.Ref_Type) = lower('SubjectType')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('SubjectStatus')
  
  ON CONFLICT(UUID) DO UPDATE SET
    Section_ID = excluded.Section_ID,
    Subject_ID = excluded.Subject_ID, 
    Teacher_ID = excluded.Teacher_ID,
    Type_ID = excluded.Type_ID, 
    Status_ID = excluded.Status_ID, 
    Schedule_Code = excluded.Schedule_Code,
    Remarks = excluded.Remarks
  ;

