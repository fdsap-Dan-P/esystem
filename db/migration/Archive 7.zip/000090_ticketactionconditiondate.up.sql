----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket_Action_Condition_Date (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_Type_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Condition_ID bigint NOT NULL,
  Value Date NOT NULL,
  Value2 Date NOT NULL,
  
  CONSTRAINT Ticket_Action_Condition_Date_pkey PRIMARY KEY (UUID),
  CONSTRAINT Ticket_Action_Condition_Date_Ticket FOREIGN KEY (Ticket_Type_ID) REFERENCES Ticket_Type(ID),
  CONSTRAINT Ticket_Action_Condition_Date_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID),
  CONSTRAINT Ticket_Action_Condition_Date_Condi FOREIGN KEY (Condition_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Action_Condition_Date_Unique ON public.Ticket_Action_Condition_Date(Inventory_Item_ID, Specs_ID);

DROP TRIGGER IF EXISTS trgTicket_Action_Condition_Date_Ins on Ticket_Action_Condition_Date;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_Condition_Date_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Ticket_Action_Condition_Date
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTicket_Action_Condition_Date_upd on Ticket_Action_Condition_Date;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_Condition_Date_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Ticket_Action_Condition_Date
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTicket_Action_Condition_Date_del on Ticket_Action_Condition_Date;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_Condition_Date_del
---------------------------------------------------------------------------
    AFTER DELETE ON Ticket_Action_Condition_Date
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
 
  