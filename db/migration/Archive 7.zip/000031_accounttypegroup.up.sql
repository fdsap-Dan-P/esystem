----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Account_Type_Group (
----------------------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Account_Type_Group varchar(255) NOT NULL,
  Product_ID bigint NULL,
  Group_ID bigint NULL,
  IIID bigint NULL,
  Normal_Balance bool NOT NULL,
  Isgl bool NOT NULL,
  Active bool NOT NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Account_Type_Group_pkey PRIMARY KEY (ID),
  CONSTRAINT idxAccount_Type_Group_Code UNIQUE (Product_ID, Code),
  CONSTRAINT idxAccount_Type_Group_Name UNIQUE (Account_Type_Group),
  CONSTRAINT fk_Account_Type_Group_Product FOREIGN KEY (Product_ID) REFERENCES Product(ID),
  CONSTRAINT fk_Account_Type_Group_Group FOREIGN KEY (Group_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Account_Type_Group_IIID FOREIGN KEY (IIID) REFERENCES Identity_Info(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAccount_Type_Group_UUID ON public.Account_Type_Group(UUID);

DROP TRIGGER IF EXISTS trgAccount_Type_Group_Ins on Account_Type_Group;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Type_Group_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Account_Type_Group
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAccount_Type_Group_upd on Account_Type_Group;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Type_Group_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Account_Type_Group
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAccount_Type_Group_del on Account_Type_Group;
---------------------------------------------------------------------------
CREATE TRIGGER trgAccount_Type_Group_del
---------------------------------------------------------------------------
    AFTER DELETE ON Account_Type_Group
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


----------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.vwAccount_Type_Group
----------------------------------------------------------------------------------------
AS SELECT 
    Acc.ID, mr.UUID,
    Acc.Code,
    Acc.Account_Type_Group,
    
    md.ID Product_ID, md.Product_Name,
    
    grp.ID Account_Type_Group_Group_ID, grp.UUID Account_Type_Group_GroupUUID, 
    grp.Title Account_Type_Group_Group,

    Acc.Normal_Balance,
    Acc.isgl,
    Acc.active,
    
    mr.Mod_Ctr,
    Acc.Other_Info,
    mr.Created,
    mr.Updated 
   FROM Account_Type_Group Acc
   INNER JOIN Main_Record mr on mr.UUID = Acc.UUID
   JOIN Product md ON Acc.Product_ID = md.ID
   JOIN Reference grp ON grp.ID = Acc.Group_ID;
   
   INSERT INTO Account_Type_Group(
     Code, Account_Type_Group, Product_ID, Group_ID, 
     Normal_Balance, isgl, active, Other_Info) 
   SELECT 
     a.Code, a.Account_Type_Group, m.ID Product_ID, grp.ID Group_ID, 
     a.Normal_Balance, a.isgl, a.active, NULL 
   FROM (Values
      (30,'Time Deposit','Bank Deposit','Main',NULL,FALSE,FALSE,TRUE),
      (20,'Savings Deposit','Bank Deposit','Main',NULL,FALSE,FALSE,TRUE),
      (10,'Demand Deposit','Bank Deposit','Main',NULL,FALSE,FALSE,TRUE),
      (100,'Golden Life 100','Collecting Facility','MicroInsurance',NULL,FALSE,FALSE,TRUE),
      (50,'Golden Life 50','Collecting Facility','MicroInsurance',NULL,FALSE,FALSE,TRUE),
      (20,'Mutual Fund','Collecting Facility','MicroInsurance',NULL,FALSE,FALSE,TRUE),
      (2,'Katuparan','Collecting Facility','MicroInsurance',NULL,FALSE,FALSE,TRUE),
      (1,'Loan Redemption Fund','Collecting Facility','MicroInsurance',NULL,FALSE,FALSE,TRUE),
      (800,'Donation','Donation','Regular',NULL,FALSE,FALSE,TRUE),
      (60,'Transportation Equipment','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (40,'Leasehold Rights and Improvements','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (10,'Land','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (50,'Information Technology Equipment','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (70,'Furniture, Fixtures and Equipment','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (80,'Building Under Construction','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (20,'Building','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (30,'Appraisal Increment (With MB Approval)','Fixed Asset','Main',NULL,TRUE,FALSE,TRUE),
      (389,'Tindahan ni Inay','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (388,'DSHP - Zero Drop Out','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (387,'DSHP - Solar','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (386,'DSHP - Sikap 2','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (385,'DSHP - Sikap 1','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (384,'DSHP - MA - Insurance Premium','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (383,'DSHP - High School','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (382,'DSHP - College','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (381,'DSHP - Agri','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (373,'MA-Sagip Plan Premium','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (335,'Sikap-MSB','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (327,'CBS','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (319,'Microfinance Plus','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (318,'MF - Housing','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (316,'Agri Loan','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (311,'Sikap 1 - GLIP','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (310,'Sikap RCF','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (306,'Sipag','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (305,'Sagip','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (304,'Sikap 4','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (303,'Sikap 3','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (302,'Sikap Additional','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (301,'Sikap 1','Loan','Microfinance',NULL,TRUE,FALSE,TRUE),
      (401,'Small Business Loan','Loan','SME',NULL,TRUE,FALSE,TRUE),
      (352,'SME Investment','Loan','SME',NULL,TRUE,FALSE,TRUE),
      (351,'SME Working Capital','Loan','SME',NULL,TRUE,FALSE,TRUE),
      (399,'Secured Restructured','Loan','Restructured',NULL,TRUE,FALSE,TRUE),
      (398,'Unsecured Restructured','Loan','Restructured',NULL,TRUE,FALSE,TRUE),
      (397,'Reserve','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (372,'MA-Insurance Premium','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (371,'MA-Bundled Insurance 2','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (370,'Bundle Insurance','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (360,'Bagong Araw','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (345,'Salary - Employee','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (344,'Educational - Zero Dropout','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (343,'Educational','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (342,'Salary','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (341,'Individual','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (339,'Educational - College','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (338,'Educational - High School','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (336,'Other Loan - Solar','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (334,'Educational - MSB','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (333,'Seasonal','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (332,'Calamity','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (331,'Emergency','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (326,'Hapinoy','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (324,'Other Loan - Cellphone','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (323,'Other Loan - SSS','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (322,'Health Loan - Akap','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (321,'Health Loan - Philhealth','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (317,'Kabuhayan Loan Program','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (308,'Health Loan - Insurance Premium','Loan','Other',NULL,TRUE,FALSE,TRUE),
      (20,'Borrowed Funds','Loans Payable','Main',NULL,FALSE,FALSE,TRUE),
      (10,'Bills Payable','Loans Payable','Main',NULL,FALSE,FALSE,TRUE),
      (120,'EMPC Pension','Payable','Main',NULL,FALSE,FALSE,TRUE),
      (110,'EMPC Loan','Payable','Main',NULL,FALSE,FALSE,TRUE),
      (100,'Employees Contribution','Payable','Main',NULL,FALSE,FALSE,TRUE),
      (20,'Overages','Payable','Main',NULL,FALSE,FALSE,TRUE),
      (10,'Accounts Payable','Payable','Main',NULL,FALSE,FALSE,TRUE),
      (20,'Shortages','Receivable','Main',NULL,TRUE,FALSE,TRUE),
      (10,'Accounts Receivable','Receivable','Main',NULL,TRUE,FALSE,TRUE),
      (700,'Cash Advance','Receivable','Regular',NULL,FALSE,FALSE,TRUE),
      (240,'Special Time Deposit','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (80,'Tagumpay Account (Member)','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (70,'Tagumpay Account (Non-Member)','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (50,'Kayang-Kaya Account','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (40,'Tagumpay Savings','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (30,'Maagap Savings Account','Savings','Regular',NULL,FALSE,FALSE,TRUE),
      (60,'Pledge Account','Savings','Microfinance',NULL,FALSE,FALSE,TRUE),
      (120,'Interest Bearing Current','Savings','Current Account',NULL,FALSE,FALSE,TRUE),
      (710,'Regular Current Account','Savings','Current Account',NULL,FALSE,FALSE,TRUE),
      (720,'Elementary','School','Regular',NULL,FALSE,FALSE,TRUE),
      (730,'High School','School','Regular',NULL,FALSE,FALSE,TRUE),
      (740,'College','School','Regular',NULL,FALSE,FALSE,TRUE),
      (750,'Seminars','School','Regular',NULL,FALSE,FALSE,TRUE)
      )   
    a(Code, Account_Type_Group, Product, grp, Alternate_ID, Normal_Balance, isGL, Active) 

      
  INNER JOIN Product m on m.Product_Name = a.Product
  INNER JOIN vwReference grp on lower(grp.Title) = lower(a.grp) 
    and lower(grp.Ref_Type) = 'accounttypegroup'
  
  ON CONFLICT (Account_Type_Group) DO UPDATE SET
    Product_ID = EXCLUDED.Product_ID,
    Group_ID = EXCLUDED.Group_ID,
    Code = EXCLUDED.Code,
    active = EXCLUDED.active,   
    Normal_Balance = EXCLUDED.Normal_Balance,
    isgl = EXCLUDED.isgl,
    Account_Type_Group = EXCLUDED.Account_Type_Group,
    Other_Info = EXCLUDED.Other_Info
  ;
