----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket_Action_Condition_String (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_Type_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Condition_ID bigint NOT NULL,
  Value text NOT NULL,
  
  CONSTRAINT Trn_Ticket_Action_Condition_pkey PRIMARY KEY (UUID),
  CONSTRAINT Ticket_Action_Condition_String_Ticket FOREIGN KEY (Ticket_Type_ID) REFERENCES Ticket_Type(ID),
  CONSTRAINT Ticket_Action_Condition_String_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID),
  CONSTRAINT Ticket_Action_Condition_String_Condi FOREIGN KEY (Condition_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxTrn_Ticket_Action_Condition_Unique ON public.Trn_Ticket_Action_Condition(Trn_Head_ID, Specs_ID);

DROP TRIGGER IF EXISTS trgTrn_Ticket_Action_Condition_Ins on Trn_Ticket_Action_Condition;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Ticket_Action_Condition_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Trn_Ticket_Action_Condition
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTrn_Ticket_Action_Condition_upd on Trn_Ticket_Action_Condition;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Ticket_Action_Condition_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Trn_Ticket_Action_Condition
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTrn_Ticket_Action_Condition_del on Trn_Ticket_Action_Condition;
---------------------------------------------------------------------------
CREATE TRIGGER trgTrn_Ticket_Action_Condition_del
---------------------------------------------------------------------------
    AFTER DELETE ON Trn_Ticket_Action_Condition
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
 