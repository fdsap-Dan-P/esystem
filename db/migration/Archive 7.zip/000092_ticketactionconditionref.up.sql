----------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public. Ticket_Action_Condition_Ref (
----------------------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_Type_ID bigint NOT NULL,
  Item_ID bigint NOT NULL,
  Condition_ID bigint NOT NULL,
  Ref_ID bigint NOT NULL,
  
  CONSTRAINT  Ticket_Action_Condition_Ref_pkey PRIMARY KEY (UUID),
  CONSTRAINT Ticket_Action_Condition_Ref_Ticket FOREIGN KEY (Ticket_Type_ID) REFERENCES Ticket_Type(ID),
  CONSTRAINT Ticket_Action_Condition_Ref_Item FOREIGN KEY (Item_ID) REFERENCES Reference(ID),
  CONSTRAINT Ticket_Action_Condition_Ref_Condi FOREIGN KEY (Condition_ID) REFERENCES Reference(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx Ticket_Action_Condition_Ref_Unique ON public. Ticket_Action_Condition_Ref(Trn_Head_ID, Specs_ID);


DROP TRIGGER IF EXISTS trg Ticket_Action_Condition_Ref_Ins on  Ticket_Action_Condition_Ref;
---------------------------------------------------------------------------
CREATE TRIGGER trg Ticket_Action_Condition_Ref_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON  Ticket_Action_Condition_Ref
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trg Ticket_Action_Condition_Ref_upd on  Ticket_Action_Condition_Ref;
---------------------------------------------------------------------------
CREATE TRIGGER trg Ticket_Action_Condition_Ref_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON  Ticket_Action_Condition_Ref
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trg Ticket_Action_Condition_Ref_del on  Ticket_Action_Condition_Ref;
---------------------------------------------------------------------------
CREATE TRIGGER trg Ticket_Action_Condition_Ref_del
---------------------------------------------------------------------------
    AFTER DELETE ON  Ticket_Action_Condition_Ref
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
 