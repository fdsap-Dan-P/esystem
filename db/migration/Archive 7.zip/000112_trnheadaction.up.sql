---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Action_Ticket (
---------------------------------------------------------------------------
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_ID bigint NOT NULL,
  Type_ID bigint NOT NULL,
  Milestone_ID bigint NULL,
  User_ID bigint NOT NULL,
  Action_Ticket_Date  timestamptz NULL,
  Reference varchar(20) NULL,
  Remarks varchar(100) NULL,
  Other_Info jsonb NULL,
  
  CONSTRAINT Action_Ticket_pkey PRIMARY KEY (UUID),
  CONSTRAINT fkAction_TicketTrn FOREIGN KEY (Ticket_ID) REFERENCES Trn_Head(ID),
  CONSTRAINT fkAction_Ticket_Type FOREIGN KEY (Type_ID) REFERENCES Reference(ID),
  CONSTRAINT fkAction_Ticket_Milestone FOREIGN KEY (Milestone_ID) REFERENCES Reference(ID),
  CONSTRAINT fkAction_TicketUserName FOREIGN KEY (User_ID) REFERENCES Users(ID)
);

DROP TRIGGER IF EXISTS trgAction_TicketIns on Action_Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_TicketIns
---------------------------------------------------------------------------
    BEFORE INSERT ON Action_Ticket
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAction_Ticketupd on Action_Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_Ticketupd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Action_Ticket
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAction_Ticket_del on Action_Ticket;
---------------------------------------------------------------------------
CREATE TRIGGER trgAction_Ticket_del
---------------------------------------------------------------------------
    AFTER DELETE ON Action_Ticket
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();


  INSERT INTO Action_Ticket(
    UUID, Ticket_ID, Type_ID, Milestone_ID, User_ID, Action_Ticket_Date , Reference, Remarks)
  SELECT 
    a.UUID, t.ID Ticket_ID,
    typ.ID Type_ID, mile.ID Milestone_ID, ul.ID User_ID, 
    cast(a.Action_Ticket_Date  as Date), a.Reference, a.Remarks
    
  FROM (Values
      ('8ac29dea-7e8b-43a1-a2de-c85b39f4372c'::UUID,'da970ce4-dc2f-44af-b1a8-49a987148922'::UUID,'Posted','Execution','erick1421@gmail.com', '01/01/2020', 'ref', 'test')
      )   
    a(UUID, ticketUUID, Action_Ticket_Type, Milesstone, Login_Name, Action_Ticket_Date , Reference, Remarks)  

  INNER JOIN Ticket t on t.UUID = a.ticketUUID
  LEFT JOIN vwReference typ  on lower(typ.Title) = lower(a.Action_Ticket_Type) and lower(typ.Ref_Type) = lower('ActionList')
  LEFT JOIN vwReference mile on lower(mile.short_name) = lower(a.Milesstone) and lower(mile.Ref_Type) = lower('Milestone')
  LEFT JOIN Users ul     on lower(ul.Login_Name) = lower(a.Login_Name) 
  
  ON CONFLICT(UUID)
  DO UPDATE SET
    Ticket_ID = excluded.Ticket_ID,
    Type_ID = excluded.Type_ID,
    Milestone_ID = excluded.Milestone_ID,
    User_ID = excluded.User_ID,
    Action_Ticket_Date  = excluded.Action_Ticket_Date ,
    Reference = excluded.Reference,
    Remarks = excluded.Remarks
  ; 