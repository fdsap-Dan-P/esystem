---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Answer (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Subject_Event_ID bigint NOT NULL,
  Question_ID bigint NOT NULL,
  Answers jsonb NULL,
  Points numeric(8,5) NOT NULL DEFAULT 0,
  Remarks varchar(200) NULL,
  Other_Info jsonb NULL,
 
  CONSTRAINT Answer_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Answer_Event FOREIGN KEY (Subject_Event_ID) REFERENCES Subject_Event(ID),
  CONSTRAINT fk_Answer_Question FOREIGN KEY (Question_ID) REFERENCES Question(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxAnswer_UUID ON public.Answer(UUID);

DROP TRIGGER IF EXISTS trgAnswer_Ins on Answer;
---------------------------------------------------------------------------
CREATE TRIGGER trgAnswer_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Answer
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgAnswer_upd on Answer;
---------------------------------------------------------------------------
CREATE TRIGGER trgAnswer_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Answer
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgAnswer_del on Answer;
---------------------------------------------------------------------------
CREATE TRIGGER trgAnswer_del
---------------------------------------------------------------------------
    AFTER DELETE ON Answer
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
   INSERT into Answer(
    UUID, Subject_Event_ID, Question_ID, Answers, Points, Remarks
    )
 
  SELECT
    Acc.UUID, eve.ID Subject_Event_ID, que.ID Question_ID, Acc.Answer, Acc.Points, Acc.Remarks
  FROM (Values
      ('891e0a8b-9c46-48cc-8029-357a0f03180b'::UUID, '75c261eb-e4c3-4fbb-8173-ccf3f803c1b6'::UUID, 'a4bc09b4-db99-4afb-be43-22b4938b1582'::UUID, '[{"Answer":"Manila","Correct":1, "Score":1}]'::jsonb, 1, 'Remarks')
      )   
  Acc(
    UUID, EventUUID, QuesUUID, Answer, Points, Remarks
    )
    
  LEFT JOIN Subject_Event eve on eve.UUID = Acc.EventUUID
  LEFT JOIN Question que on que.UUID = Acc.QuesUUID
  
  ON CONFLICT(UUID) DO UPDATE SET
    Subject_Event_ID  = excluded.Subject_Event_ID,
    Question_ID = excluded.Question_ID,
    Answers = excluded.Answers,
    Points = excluded.Points,
    Remarks = excluded.Remarks
  ;
