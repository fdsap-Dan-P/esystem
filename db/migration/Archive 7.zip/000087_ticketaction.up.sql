---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.Ticket_Action (
---------------------------------------------------------------------------
  ID BIGSERIAL NOT NULL,
  UUID uuid NOT NULL DEFAULT uuid_generate_v4(),
  Ticket_Type_ID bigint NOT NULL,
  Ticket_Type Varchar(200) NOT NULL,
  Action_ID bigint NULL,
  Action bigint NULL,
  Action_Link_ID bigint NULL DEFAULT '',
  Other_Info jsonb NULL,
 
  CONSTRAINT Ticket_Action_pkey PRIMARY KEY (ID),
  CONSTRAINT fk_Ticket_Action_Ticket FOREIGN KEY (Ticket_Type_ID) REFERENCES Ticket_Type(ID),
  CONSTRAINT fk_Ticket_Action_Action FOREIGN KEY (Action_ID) REFERENCES Reference(ID),
  CONSTRAINT fk_Ticket_Action_Status FOREIGN KEY (Action_Link_ID) REFERENCES Action_Link(ID)
);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Action_UUID ON public.Ticket_Action(UUID);
CREATE UNIQUE INDEX IF NOT EXISTS idxTicket_Action_Subject ON public.Ticket_Action(Ticket_ID, Action_ID);

DROP TRIGGER IF EXISTS trgTicket_Action_Ins on Ticket_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_Ins
---------------------------------------------------------------------------
    BEFORE INSERT ON Ticket_Action
    FOR EACH ROW
    EXECUTE PROCEDURE trgGenericInsert();
 
DROP TRIGGER IF EXISTS trgTicket_Action_upd on Ticket_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_upd
---------------------------------------------------------------------------
    BEFORE UPDATE ON Ticket_Action
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*)
    EXECUTE PROCEDURE trgGenericUpdate();

DROP TRIGGER IF EXISTS trgTicket_Action_del on Ticket_Action;
---------------------------------------------------------------------------
CREATE TRIGGER trgTicket_Action_del
---------------------------------------------------------------------------
    AFTER DELETE ON Ticket_Action
    FOR EACH ROW 
    EXECUTE FUNCTION trgGenericDelete();
  
  INSERT into Ticket_Action(
    UUID, Ticket_ID, Action_ID, Status_ID, Remarks
    )
  SELECT
    a.UUID, tic.ID Ticket_ID, act.ID Action_ID, stat.ID Status_ID, Remarks
  FROM (Values
      ('c03d8bd1-1fc7-4e2f-984b-a80e4c01c4e0'::UUID, 'ecd7915c-4335-43a2-b2fa-b361cb125b6e'::UUID, 'Encoded', 'Active','Remarks for Action List')
      )   
    a(UUID, Ticket_UUID, Action, Status, Remarks)   
  LEFT JOIN Ticket_Type tic on a.Ticket_UUID = tic.UUID
  LEFT JOIN vwReference act on lower(act.Title) = lower(a.Action) and lower(act.Ref_Type) = lower('ActionList')
  LEFT JOIN vwReference stat on lower(stat.Title) = lower(a.Status) and lower(stat.Ref_Type) = lower('ActionListStatus')
    
  ON CONFLICT(UUID) DO UPDATE SET
    Ticket_ID = excluded.Ticket_ID,
    Action_ID = excluded.Action_ID,
    Status_ID = excluded.Status_ID, 
    Remarks = excluded.Remarks;

