package model

import (
	"database/sql"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type UserConfig struct {
	Uuid           uuid.UUID       `json:"uuid"`
	UserId         int64           `json:"userId"`
	AccessConfigId int64           `json:"accessConfigId"`
	ValueInt       sql.NullInt64   `json:"valueInt"`
	ValueDecimal   decimal.Decimal `json:"valueDecimal"`
	ValueDate      sql.NullTime    `json:"valueDate"`
	ValueString    sql.NullString  `json:"valueString"`
	OtherInfo      sql.NullString  `json:"otherInfo"`
}
