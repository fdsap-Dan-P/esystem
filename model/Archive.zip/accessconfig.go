package model

import (
	"database/sql"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type AccessConfig struct {
	Uuid           uuid.UUID       `json:"uuid"`
	AccessRoleId   int64           `json:"accessRoleId"`
	AccessConfigId int64           `json:"accessConfigId"`
	ValueInt       sql.NullInt64   `json:"valueInt"`
	ValueDecimal   decimal.Decimal `json:"valueDecimal"`
	ValueDate      sql.NullTime    `json:"valueDate"`
	ValueString    sql.NullString  `json:"valueString"`
	OtherInfo      sql.NullString  `json:"otherInfo"`
}
