package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type PersonalInfo struct {
	Id             int64          `json:"Id"`
	Uuid           uuid.UUID      `json:"uuid"`
	Isadopted      sql.NullBool   `json:"isadopted"`
	MarriageDate   sql.NullTime   `json:"marriageDate"`
	KnownLanguage  sql.NullString `json:"knownLanguage"`
	Disability     int16          `json:"disability"`
	IndustryId     sql.NullInt64  `json:"industryId"`
	NationalityId  sql.NullInt64  `json:"nationalityId"`
	OccupationId   sql.NullInt64  `json:"occupationId"`
	ReligionId     sql.NullInt64  `json:"religionId"`
	SectorId       sql.NullInt64  `json:"sectorId"`
	SourceIncomeId sql.NullInt64  `json:"sourceIncomeId"`
	DisabilityId   sql.NullInt64  `json:"disabilityId"`
	OtherInfo      sql.NullString `json:"otherInfo"`
}
