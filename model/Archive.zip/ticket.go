package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
)

type Ticket struct {
	Id              int64          `json:"Id"`
	Uuid            uuid.UUID      `json:"uuid"`
	CentralOfficeID int64          `json:"CentralOfficeID"`
	TicketDate      time.Time      `json:"ticketDate"`
	TicketTypeId    int64          `json:"ticketTypeId"`
	PostedbyId      int64          `json:"postedbyId"`
	StatusId        int64          `json:"statusId"`
	Remarks         sql.NullString `json:"remarks"`
	OtherInfo       sql.NullString `json:"otherInfo"`
}
