package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type Document struct {
	Id          int64          `json:"Id"`
	Uuid        uuid.UUID      `json:"uuid"`
	DocDate     sql.NullTime   `json:"doc_date"`
	FilePath    string         `json:"filePath"`
	Thumbnail   []byte         `json:"thumbnail"`
	DoctypeId   int64          `json:"doctypeId"`
	ServerId    int64          `json:"serverId"`
	Description sql.NullString `json:"description"`
	OtherInfo   sql.NullString `json:"otherInfo"`
}
