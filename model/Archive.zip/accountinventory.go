package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type AccountInventory struct {
	Id        int64           `json:"id"`
	Uuid      uuid.UUID       `json:"uuid"`
	AccountId int64           `json:"accountId"`
	BarCode   string          `json:"packageId"`
	Code      string          `json:"itemName"`
	Quantity  decimal.Decimal `json:"quantity"`
	UnitPrice decimal.Decimal `json:"unitPrice"`
	BookValue decimal.Decimal `json:"bookValue"`
	Discount  decimal.Decimal `json:"discount"`
	TaxRate   decimal.Decimal `json:"taxRate"`
	Remarks   string          `json:"remarks"`
	OtherInfo sql.NullString  `json:"otherInfo"`
}

type InventoryItem struct {
	Id              int64          `json:"Id"`
	Uuid            uuid.UUID      `json:"uuid"`
	BarCode         sql.NullString `json:"barCode"`
	ItemName        string         `json:"itemName"`
	UniqueVariation string         `json:"uniqueVariation"`
	ParentId        sql.NullInt64  `json:"parentId"`
	GenericNameId   sql.NullInt64  `json:"genericNameId"`
	BrandNameId     sql.NullInt64  `json:"brandNameId"`
	MeasureId       int64          `json:"measureId"`
	ImageId         sql.NullInt64  `json:"imageId"`
	Remarks         string         `json:"remarks"`
	OtherInfo       sql.NullString `json:"otherInfo"`
}

type InventoryDetail struct {
	Id                 int64           `json:"Id"`
	Uuid               uuid.UUID       `json:"uuid"`
	AccountInventoryId int64           `json:"accountInventoryId"`
	InventoryItemId    int64           `json:"inventoryItemId"`
	SupplierId         sql.NullInt64   `json:"supplierId"`
	UnitPrice          decimal.Decimal `json:"unitPrice"`
	BookValue          decimal.Decimal `json:"bookValue"`
	Unit               decimal.Decimal `json:"unit"`
	MeasureId          int64           `json:"measureId"`
	BatchNumber        sql.NullString  `json:"batchNumber"`
	DateManufactured   sql.NullTime    `json:"dateManufactured"`
	DateExpired        sql.NullTime    `json:"dateExpired"`
	Remarks            string          `json:"remarks"`
	OtherInfo          sql.NullString  `json:"otherInfo"`
}

type InventorySpecsString struct {
	Uuid            uuid.UUID `json:"uuid"`
	InventoryItemId int64     `json:"inventoryItemId"`
	SpecsId         int64     `json:"specsId"`
	Value           string    `json:"value"`
}

type InventorySpecsNumber struct {
	Uuid            uuid.UUID       `json:"uuid"`
	InventoryItemId int64           `json:"inventoryItemId"`
	SpecsId         int64           `json:"specsId"`
	Value           decimal.Decimal `json:"value"`
	Value2          decimal.Decimal `json:"value2"`
	MeasureId       sql.NullInt64   `json:"MeasureId"`
}

type InventorySpecsDate struct {
	Uuid            uuid.UUID `json:"uuid"`
	InventoryItemId int64     `json:"inventoryItemId"`
	SpecsId         int64     `json:"specsId"`
	Value           time.Time `json:"value"`
	Value2          time.Time `json:"value2"`
}

type InventorySpecsRef struct {
	Uuid            uuid.UUID `json:"uuid"`
	InventoryItemId int64     `json:"inventoryItemId"`
	SpecsId         int64     `json:"specsId"`
	RefId           int64     `json:"refId"`
}

type InventoryRepository struct {
	Id                  int64          `json:"Id"`
	Uuid                uuid.UUID      `json:"UUID"`
	CentralOfficeId     int64          `json:"CentralOfficeId"`
	RepositoryCode      string         `json:"RepositoryCode"`
	Repository          string         `json:"Repository"`
	OfficeId            int64          `json:"OfficeId"`
	CustodianId         sql.NullInt64  `json:"CustodianId"`
	GeographyId         sql.NullInt64  `json:"GeographyId"`
	LocationDescription sql.NullString `json:"LocationDescription"`
	Remarks             sql.NullString `json:"Remarks"`
	OtherInfo           sql.NullString `json:"OtherInfo"`
}
