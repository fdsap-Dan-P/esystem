package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type Employee struct {
	Id          int64          `json:"Id"`
	Uuid        uuid.UUID      `json:"uuid"`
	Iiid        int64          `json:"iiid"`
	CentralId   int64          `json:"centralId"`
	EmployeeNo  sql.NullString `json:"employee_no"`
	BasicPay    float64        `json:"basicPay"`
	DateHired   sql.NullTime   `json:"date_hired"`
	DateRegular sql.NullTime   `json:"dateRegular"`
	JobGrade    int16          `json:"jobGrade"`
	JobStep     int16          `json:"jobStep"`
	LevelId     sql.NullInt64  `json:"levelId"`
	OfficeId    int64          `json:"officeId"`
	PositionId  int64          `json:"positionId"`
	StatusId    sql.NullInt64  `json:"statusId"`
	SuperiorId  sql.NullInt64  `json:"superiorId"`
	TypeId      sql.NullInt64  `json:"typeId"`
	OtherInfo   sql.NullString `json:"otherInfo"`
}
