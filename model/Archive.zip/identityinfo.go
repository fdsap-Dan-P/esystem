package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type IdentityInfo struct {
	Id                int64          `json:"Id"`
	Uuid              uuid.UUID      `json:"uuid"`
	Isperson          bool           `json:"isperson"`
	TitleId           sql.NullInt64  `json:"titleId"`
	LastName          string         `json:"lastName"`
	FirstName         sql.NullString `json:"firstName"`
	MiddleName        sql.NullString `json:"MiddleName"`
	MotherMaidenName  sql.NullString `json:"MotherMaidenName"`
	Birthday          sql.NullTime   `json:"birthday"`
	Sex               sql.NullBool   `json:"sex"`
	GenderId          sql.NullInt64  `json:"genderId"`
	CivilStatusId     sql.NullInt64  `json:"civilStatusId"`
	BirthPlaceId      sql.NullInt64  `json:"birthPlaceId"`
	ContactId         sql.NullInt64  `json:"contactId"`
	IdentityMapId     sql.NullInt64  `json:"IdentityMapId"`
	AlternateId       sql.NullString `json:"alternateId"`
	Phone             sql.NullString `json:"phone"`
	Email             sql.NullString `json:"email"`
	SimpleName        sql.NullString `json:"simpleName"`
	VecSimpleName     interface{}    `json:"vec_simpleName"`
	VecFullSimpleName interface{}    `json:"vec_fullSimpleName"`
	OtherInfo         sql.NullString `json:"otherInfo"`
}

type IdentitySpecsString struct {
	Uuid    uuid.UUID `json:"uuid"`
	Iiid    int64     `json:"iiid"`
	SpecsId int64     `json:"specsId"`
	Value   string    `json:"value"`
}

type IdentitySpecsNumber struct {
	Uuid      uuid.UUID       `json:"uuid"`
	Iiid      int64           `json:"iiid"`
	SpecsId   int64           `json:"specsId"`
	Value     decimal.Decimal `json:"value"`
	Value2    decimal.Decimal `json:"value2"`
	MeasureId sql.NullInt64   `json:"MeasureId"`
}

type IdentitySpecsDate struct {
	Uuid    uuid.UUID `json:"uuid"`
	Iiid    int64     `json:"iiid"`
	SpecsId int64     `json:"specsId"`
	Value   time.Time `json:"value"`
	Value2  time.Time `json:"value2"`
}

type IdentitySpecsRef struct {
	Uuid    uuid.UUID `json:"uuid"`
	Iiid    int64     `json:"iiid"`
	SpecsId int64     `json:"specsId"`
	RefId   int64     `json:"refId"`
}
