package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type Geography struct {
	Id             int64           `json:"Id"`
	Uuid           uuid.UUID       `json:"uuid"`
	Code           int64           `json:"code"`
	ShortName      sql.NullString  `json:"shortName"`
	Location       string          `json:"location"`
	TypeId         int64           `json:"typeId"`
	ParentId       sql.NullInt64   `json:"parentId"`
	ZipCode        sql.NullString  `json:"zipCode"`
	Latitude       sql.NullFloat64 `json:"latitude"`
	Longitude      sql.NullFloat64 `json:"longitude"`
	AddressUrl     sql.NullString  `json:"addressUrl"`
	SimpleLocation sql.NullString  `json:"simpleLocation"`
	FullLocation   sql.NullString  `json:"fullLocation"`
	OtherInfo      sql.NullString  `json:"otherInfo"`
}
