package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	Id                int64          `json:"Id"`
	Uuid              uuid.UUID      `json:"uuid"`
	Iiid              int64          `json:"iiid"`
	LoginName         string         `json:"loginName"`
	DisplayName       sql.NullString `json:"displayName"`
	AccessRoleId      int64          `json:"accessRoleId"`
	StatusId          int64          `json:"statusId"`
	DateGiven         sql.NullTime   `json:"dateGiven"`
	DateExpired       sql.NullTime   `json:"dateRxpired"`
	DateLocked        sql.NullTime   `json:"dateLocked"`
	PasswordChangedAt sql.NullTime   `json:"passwordChangedAt"`
	// UserPassword      string         `json:"userPassword"`
	HashedPassword string         `json:"hashedPassword"`
	Attempt        int16          `json:"attempt"`
	Isloggedin     sql.NullBool   `json:"isloggedin"`
	OtherInfo      sql.NullString `json:"otherInfo"`
	Thumbnail      []byte         `json:"thumbnail"`
}

// NewUser returns a new user

func HashedPassword(pass string) []byte {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(pass), bcrypt.DefaultCost)
	if err != nil {
		return []byte{}
	}
	return hashedPassword
}

func NewUser(
	iiid int64,
	loginName string,
	displayName sql.NullString,
	accessRoleId int64,
	statusId int64,
	dateGiven sql.NullTime,
	dateExpired sql.NullTime,
	dateLocked sql.NullTime,
	passwordChangedAt sql.NullTime,
	pass string,
	attempt int16,
	isloggedin sql.NullBool,
	otherInfo sql.NullString,
	thumbnail []byte) (*User, error) {

	user := &User{
		Iiid:              iiid,
		LoginName:         loginName,
		DisplayName:       displayName,
		AccessRoleId:      accessRoleId,
		StatusId:          statusId,
		DateGiven:         dateGiven,
		DateExpired:       dateExpired,
		DateLocked:        dateLocked,
		PasswordChangedAt: passwordChangedAt,
		HashedPassword:    string(HashedPassword(pass)),
		Attempt:           attempt,
		Isloggedin:        isloggedin,
		OtherInfo:         otherInfo,
		Thumbnail:         thumbnail,
	}
	return user, nil
}

// IsCorrectPassword checks if the provided password is correct or not
func (user *User) IsCorrectPassword(password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(user.HashedPassword), []byte(password))
	return err == nil
}

// Clone returns a clone of this user
func (user *User) Clone() *User {
	return &User{
		Iiid:              user.Iiid,
		LoginName:         user.LoginName,
		DisplayName:       user.DisplayName,
		AccessRoleId:      user.AccessRoleId,
		StatusId:          user.StatusId,
		DateGiven:         user.DateGiven,
		DateExpired:       user.DateExpired,
		DateLocked:        user.DateLocked,
		PasswordChangedAt: user.PasswordChangedAt,
		HashedPassword:    user.HashedPassword,
		Attempt:           user.Attempt,
		Isloggedin:        user.Isloggedin,
		Thumbnail:         user.Thumbnail,
		OtherInfo:         user.OtherInfo,
	}
}

type UserSpecsString struct {
	Uuid    uuid.UUID `json:"uuid"`
	UserId  int64     `json:"userId"`
	SpecsId int64     `json:"specsId"`
	Value   string    `json:"value"`
}

type UserSpecsNumber struct {
	Uuid      uuid.UUID       `json:"uuid"`
	UserId    int64           `json:"userId"`
	SpecsId   int64           `json:"specsId"`
	Value     decimal.Decimal `json:"value"`
	Value2    decimal.Decimal `json:"value2"`
	MeasureId sql.NullInt64   `json:"MeasureId"`
}

type UserSpecsDate struct {
	Uuid    uuid.UUID `json:"uuid"`
	UserId  int64     `json:"userId"`
	SpecsId int64     `json:"specsId"`
	Value   time.Time `json:"value"`
	Value2  time.Time `json:"value2"`
}

type UserSpecsRef struct {
	Uuid    uuid.UUID `json:"uuid"`
	UserId  int64     `json:"userId"`
	SpecsId int64     `json:"specsId"`
	RefId   int64     `json:"refId"`
}
