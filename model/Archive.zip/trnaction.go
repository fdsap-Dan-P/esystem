package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type TrnAction struct {
	Uuid          uuid.UUID      `json:"uuid"`
	TrnHeadId     int64          `json:"trnHeadId"`
	TypeId        int64          `json:"typeId"`
	UserId        int64          `json:"userId"`
	TrnActionDate sql.NullTime   `json:"trnActionDate"`
	Reference     sql.NullString `json:"reference"`
	Remarks       sql.NullString `json:"remarks"`
	OtherInfo     sql.NullString `json:"otherInfo"`
}
