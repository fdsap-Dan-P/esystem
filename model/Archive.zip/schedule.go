package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type Schedule struct {
	Id            int64           `json:"Id"`
	Uuid          uuid.UUID       `json:"uuid"`
	AccountId     int64           `json:"accountId"`
	Series        int16           `json:"series"`
	DueDate       time.Time       `json:"dueDate"`
	DuePrin       decimal.Decimal `json:"duePrin"`
	DueInt        decimal.Decimal `json:"due_int"`
	EndPrin       decimal.Decimal `json:"end_prin"`
	EndInt        decimal.Decimal `json:"end_int"`
	CarryingValue decimal.Decimal `json:"carrying_value"`
	Realizable    decimal.Decimal `json:"realizable"`
	OtherInfo     sql.NullString  `json:"otherInfo"`
}
