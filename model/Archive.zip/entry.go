package model

import (
	"time"

	"github.com/shopspring/decimal"
)

type Entry struct {
	Id        int64 `json:"Id"`
	AccountId int64 `json:"accountId"`
	// can be negative or positive
	Amount    decimal.Decimal `json:"amount"`
	CreatedAt time.Time       `json:"createdAt"`
}
