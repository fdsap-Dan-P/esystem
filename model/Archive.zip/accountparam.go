package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

type AccountParam struct {
	Uuid            uuid.UUID       `json:"uuid"`
	ParamItemId     int64           `json:"param_itemId"`
	TypeId          int64           `json:"TypeId"`
	DateImplemented time.Time       `json:"date_implemented"`
	ValueInt        sql.NullInt64   `json:"valueInt"`
	ValueDecimal    decimal.Decimal `json:"valueDecimal"`
	ValueDate       sql.NullTime    `json:"valueDate"`
	ValueString     sql.NullString  `json:"valueString"`
	OtherInfo       sql.NullString  `json:"otherInfo"`
}
