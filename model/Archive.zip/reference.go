package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type Reference struct {
	Id        int64          `json:"Id"`
	Uuid      uuid.UUID      `json:"uuid"`
	Code      int64          `json:"code"`
	ShortName sql.NullString `json:"shortName"`
	Title     string         `json:"title"`
	ParentId  sql.NullInt64  `json:"parentId"`
	RefTypeId int64          `json:"TypeId"`
	Remark    sql.NullString `json:"remark"`
	OtherInfo sql.NullString `json:"otherInfo"`
}
