package model

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
)

type Comment struct {
	Uuid       uuid.UUID      `json:"uuid"`
	RecordUuid uuid.UUID      `json:"recordUuid"`
	UserId     int64          `json:"userId"`
	Comment    string         `json:"comment"`
	OtherInfo  sql.NullString `json:"otherInfo"`
}

type Likes struct {
	Uuid      uuid.UUID      `json:"uuid"`
	UserId    int64          `json:"userId"`
	Mood      int32          `json:"mood"`
	DateLiked time.Time      `json:"dateLiked"`
	OtherInfo sql.NullString `json:"otherInfo"`
}

type Follower struct {
	UserId       int64     `json:"userId"`
	FollowerId   int64     `json:"followerId"`
	DateFollowed time.Time `json:"dateFollowed"`
	IsFollower   bool      `json:"isFollowed"`
}
