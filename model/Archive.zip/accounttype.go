package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type AccountType struct {
	Id            int64          `json:"Id"`
	Uuid          uuid.UUID      `json:"uuid"`
	Code          int64          `json:"code"`
	AccountType   string         `json:"accountType"`
	ProductId     int64          `json:"productId"`
	GroupId       sql.NullInt64  `json:"groupId"`
	Iiid          sql.NullInt64  `json:"iiid"`
	NormalBalance bool           `json:"normalBalance"`
	Isgl          bool           `json:"isgl"`
	Active        bool           `json:"active"`
	OtherInfo     sql.NullString `json:"otherInfo"`
}

type AccountTypeGroup struct {
	Id            int64          `json:"Id"`
	Uuid          uuid.UUID      `json:"uuid"`
	Code          int64          `json:"code"`
	AccountType   string         `json:"accountType"`
	ProductId     int64          `json:"productId"`
	GroupId       sql.NullInt64  `json:"groupId"`
	Iiid          sql.NullInt64  `json:"iiid"`
	NormalBalance bool           `json:"normalBalance"`
	Isgl          bool           `json:"isgl"`
	Active        bool           `json:"active"`
	OtherInfo     sql.NullString `json:"otherInfo"`
}
