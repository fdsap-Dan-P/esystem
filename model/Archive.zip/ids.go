package model

import (
	"database/sql"

	"github.com/google/uuid"
)

type Ids struct {
	Uuid             uuid.UUID      `json:"uuid"`
	Iiid             int64          `json:"iiid"`
	Series           int16          `json:"series"`
	IdNumber         string         `json:"IdNumber"`
	RegistrationDate sql.NullTime   `json:"registrationDate"`
	ValidityDate     sql.NullTime   `json:"ValidityDate"`
	TypeId           int64          `json:"IdTypeId"`
	OtherInfo        sql.NullString `json:"otherInfo"`
}
